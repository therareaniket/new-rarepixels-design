"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Link from "next/link";
import "./services.css";

gsap.registerPlugin(ScrollTrigger);

const ServicesSection = () => {

	const sectionRef = useRef<HTMLDivElement | null>(null);

	useLayoutEffect(() => {
		const section = sectionRef.current;

		if (!section) return;

		const ctx = gsap.context(() => {
			const circleWrapper =
				section.querySelector<HTMLElement>(".services-circle-wrapper");

			const circleRotator =
				section.querySelector<HTMLElement>(".services-circle-rotator");

			const activeDotPosition =
				section.querySelector<HTMLElement>(
					".services-active-dot-position"
				);

			const serviceContents = gsap.utils.toArray<HTMLElement>(
				".services-text-pointers",
				section
			);

			const serviceNumbers = gsap.utils.toArray<HTMLElement>(
				".services-number",
				section
			);

			const serviceVisuals = gsap.utils.toArray<HTMLElement>(
				".services-visuals-items",
				section
			);

			if (
				!circleWrapper ||
				!circleRotator ||
				!activeDotPosition ||
				serviceContents.length !== 4 ||
				serviceNumbers.length !== 4 ||
				serviceVisuals.length !== 4
			) {
				return;
			}

			const totalSteps = serviceContents.length;

			const themeColors = [
				"#D5D8E2",
				"#FBF9E9",
				"#FCD4E9",
				"#F5F8F5",
			];

			let currentStep = 0;
			let isAnimating = false;
			let isObserverActive = false;

			let sectionTrigger: ScrollTrigger | null = null;

			/*
			 * Reads a CSS angle variable and converts it to a number.
			 *
			 * Example:
			 * "90deg" becomes 90
			 * "-30deg" becomes -30
			 */
			function getCSSAngle(variableName: string) {
				const value = getComputedStyle(circleWrapper)
					.getPropertyValue(variableName)
					.trim();

				return parseFloat(value) || 0;
			}

			function getNumberStartAngle() {
				return getCSSAngle("--number-start-angle");
			}

			function getNumberGap() {
				return getCSSAngle("--number-gap");
			}

			/*
			 * The circle rotates in the opposite direction
			 * of the number placement.
			 *
			 * Desktop:
			 * number gap = 90
			 * circle rotation = -90 per step
			 *
			 * Tablet:
			 * number gap = -30
			 * circle rotation = +30 per step
			 */
			function getCircleRotation(step: number) {
				return step * -getNumberGap();
			}

			/*
			 * The dot is inside circleRotator, so it also receives
			 * the parent circle rotation.
			 *
			 * This inverse rotation keeps the dot at the centered
			 * active-number position.
			 */
			function getDotRotation(step: number) {
				const startAngle = getNumberStartAngle();
				const circleRotation = getCircleRotation(step);

				return startAngle - circleRotation;
			}

			/*
			 * Initial state
			 */
			gsap.set(section, {
				backgroundColor: themeColors[0],
			});

			gsap.set(circleRotator, {
				rotation: getCircleRotation(0),
				transformOrigin: "50% 50%",
			});

			gsap.set(activeDotPosition, {
				rotation: getDotRotation(0),
				transformOrigin: "left center",
			});

			gsap.set(serviceContents, {
				autoAlpha: 0,
				y: 60,
				pointerEvents: "none",
			});

			gsap.set(serviceContents[0], {
				autoAlpha: 1,
				y: 0,
				pointerEvents: "auto",
			});

			gsap.set(serviceNumbers, {
				opacity: 0.5,
			});

			gsap.set(serviceNumbers[0], {
				opacity: 1,
			});

			gsap.set(serviceVisuals, {
				autoAlpha: 0,
				scale: 0.6,
				transformOrigin: "50% 50%",
				pointerEvents: "none",
			});

			gsap.set(serviceVisuals[0], {
				autoAlpha: 1,
				scale: 1,
				pointerEvents: "auto",
			});

			/*
			 * Immediately set a particular service step.
			 * Used when entering this section.
			 */
			function setActiveStep(step: number) {
				currentStep = step;
				isAnimating = false;

				gsap.killTweensOf([
					section,
					circleRotator,
					activeDotPosition,
					...serviceContents,
					...serviceNumbers,
					...serviceVisuals,
				]);

				gsap.set(section, {
					backgroundColor: themeColors[step],
				});

				gsap.set(circleRotator, {
					rotation: getCircleRotation(step),
				});

				gsap.set(activeDotPosition, {
					rotation: getDotRotation(step),
				});

				gsap.set(serviceContents, {
					autoAlpha: 0,
					y: 60,
					pointerEvents: "none",
				});

				gsap.set(serviceContents[step], {
					autoAlpha: 1,
					y: 0,
					pointerEvents: "auto",
				});

				gsap.set(serviceNumbers, {
					opacity: 0.5,
				});

				gsap.set(serviceNumbers[step], {
					opacity: 1,
				});

				gsap.set(serviceVisuals, {
					autoAlpha: 0,
					scale: 0.6,
					pointerEvents: "none",
				});

				gsap.set(serviceVisuals[step], {
					autoAlpha: 1,
					scale: 1,
					pointerEvents: "auto",
				});
			}

			/*
			 * Animate to the next or previous service.
			 */
			function goToStep(nextStep: number) {
				if (isAnimating) return;

				/*
				 * Leave the section from the bottom.
				 */
				if (nextStep >= totalSteps) {
					disableObserver();

					if (sectionTrigger) {
						window.scrollTo({
							top: sectionTrigger.end + 2,
							behavior: "auto",
						});
					}

					return;
				}

				/*
				 * Leave the section from the top.
				 */
				if (nextStep < 0) {
					disableObserver();

					if (sectionTrigger) {
						window.scrollTo({
							top: Math.max(
								0,
								sectionTrigger.start - 2
							),
							behavior: "auto",
						});
					}

					return;
				}

				if (nextStep === currentStep) return;

				const previousContent =
					serviceContents[currentStep];

				const nextContent =
					serviceContents[nextStep];

				const previousNumber =
					serviceNumbers[currentStep];

				const nextNumber =
					serviceNumbers[nextStep];

				const previousVisual =
					serviceVisuals[currentStep];

				const nextVisual =
					serviceVisuals[nextStep];

				isAnimating = true;
				currentStep = nextStep;

				const circleRotation =
					getCircleRotation(currentStep);

				const dotRotation =
					getDotRotation(currentStep);

				gsap.set(nextContent, {
					autoAlpha: 0,
					y: 60,
					pointerEvents: "none",
				});

				gsap.set(nextVisual, {
					autoAlpha: 0,
					scale: 0.6,
					pointerEvents: "none",
				});

				const stepTimeline = gsap.timeline({
					defaults: {
						overwrite: "auto",
					},

					onComplete: () => {
						isAnimating = false;
					},

					onInterrupt: () => {
						isAnimating = false;
					},
				});

				/*
				 * Background color
				 */
				stepTimeline.to(
					section,
					{
						backgroundColor: themeColors[nextStep],
						duration: 0.7,
						ease: "power2.inOut",
					},
					0
				);

				/*
				 * Previous text exits
				 */
				stepTimeline.to(
					previousContent,
					{
						autoAlpha: 0,
						y: -60,
						pointerEvents: "none",
						duration: 0.35,
						ease: "power2.in",
					},
					0
				);

				/*
				 * Circle rotation
				 */
				stepTimeline.to(
					circleRotator,
					{
						rotation: circleRotation,
						duration: 0.7,
						ease: "power2.inOut",
					},
					0
				);

				/*
				 * Active dot movement
				 */
				stepTimeline.to(
					activeDotPosition,
					{
						rotation: dotRotation,
						duration: 0.7,
						ease: "power2.inOut",
					},
					0
				);

				/*
				 * Previous number becomes inactive
				 */
				stepTimeline.to(
					previousNumber,
					{
						opacity: 0.5,
						duration: 0.3,
						ease: "power2.out",
					},
					0
				);

				/*
				 * Next number becomes active
				 */
				stepTimeline.to(
					nextNumber,
					{
						opacity: 1,
						duration: 0.3,
						ease: "power2.out",
					},
					0.35
				);

				/*
				 * Previous visual exits
				 */
				stepTimeline.to(
					previousVisual,
					{
						autoAlpha: 0,
						scale: 0.6,
						pointerEvents: "none",
						duration: 0.35,
						ease: "power2.in",
					},
					0
				);

				/*
				 * Next visual enters
				 */
				stepTimeline.to(
					nextVisual,
					{
						autoAlpha: 1,
						scale: 1,
						pointerEvents: "auto",
						duration: 1,
						ease: "back.out(1.5)",
					},
					0.2
				);

				/*
				 * Next text enters
				 */
				stepTimeline.to(
					nextContent,
					{
						autoAlpha: 1,
						y: 0,
						pointerEvents: "auto",
						duration: 0.5,
						ease: "power2.out",
					},
					0.25
				);
			}

			/*
			 * Wheel and touch observer
			 */
			const scrollObserver = ScrollTrigger.observe({
				target: window,
				type: "wheel,touch",
				preventDefault: true,
				allowClicks: true,
				tolerance: 10,

				onDown: () => {
					goToStep(currentStep + 1);
				},

				onUp: () => {
					goToStep(currentStep - 1);
				},
			});

			scrollObserver.disable();

			function enableObserver(
				position: "start" | "end"
			) {
				if (isObserverActive) return;

				isObserverActive = true;

				if (sectionTrigger) {
					const holdPosition =
						position === "start"
							? sectionTrigger.start + 1
							: sectionTrigger.end - 1;

					window.scrollTo({
						top: holdPosition,
						behavior: "auto",
					});
				}

				scrollObserver.enable();
			}

			function disableObserver() {
				isObserverActive = false;
				scrollObserver.disable();
			}

			/*
			 * Pinned section
			 */
			sectionTrigger = ScrollTrigger.create({
				id: "services-circle",
				trigger: section,
				start: "top top",
				end: "+=100%",
				pin: true,
				pinSpacing: true,
				anticipatePin: 1,
				invalidateOnRefresh: true,

				onEnter: () => {
					setActiveStep(0);
					enableObserver("start");
				},

				onEnterBack: () => {
					setActiveStep(totalSteps - 1);
					enableObserver("end");
				},

				onLeave: () => {
					disableObserver();
				},

				onLeaveBack: () => {
					disableObserver();
				},
			});

			const refreshFrame = requestAnimationFrame(() => {
				ScrollTrigger.refresh();
			});

			return () => {
				cancelAnimationFrame(refreshFrame);
				scrollObserver.kill();
				sectionTrigger?.kill();
			};
		}, section);

		return () => {
			ctx.revert();
		};
	}, []);

	return (
		<section className=" py-[40px] services-circle-section">
			<div ref={sectionRef} className="services-circle-inner">
				<div className="container relative">
					<div className="services-section-wrapper flex items-center w-[100%]">
						<div className="services-circle-wrapper">
							<div className="services-circle-rotator">
								<div className="services-circle">
									<div className="services-number-position" style={{ "--number-index": 0 } as React.CSSProperties} >
										<span className="services-number font-semibold h2">01</span>
									</div>

									<div className="services-number-position" style={{ "--number-index": 1 } as React.CSSProperties} >
										<span className="services-number font-semibold h2">02</span>
									</div>

									<div className="services-number-position" style={{ "--number-index": 2 } as React.CSSProperties} >
										<span className="services-number font-semibold h2">03</span>
									</div>

									<div className="services-number-position" style={{ "--number-index": 3 } as React.CSSProperties} >
										<span className="services-number font-semibold h2">04</span>
									</div>
								</div>

								<div className="services-active-dot-position">
									<div className="services-active-dot">
										<div className="services-active-dot-inner w-[16px] h-[16px] rounded-full bg-[#ED0180]"></div>
									</div>
								</div>
							</div>
						</div>

						<div className="services-card-wrapper services-card-desktop">
							<div className="services-text-wrapper w-[689px] h-[416px] flex flex-col translate-x-[65%] relative">
								<div className="services-desktop-text ">
									<div className="services-ui-ux-text services-text-pointers">
										<h2 className="font-semibold ">UI/UX Design Services</h2>
										<p className="font-normal text-18 flex flex-col gap-[18px] mt-[20px] w-[602px]">
											<span>We design digital experiences that feel effortless from the first click to the final action. Every interface is built around how your users actually think and behave - not adapted from a template or copied from a trend. </span>
											<span>From initial research through to pixel-perfect delivery, every design decision is intentional and grounded in real user insight. </span>
										</p>

										<div className="services-content-chips mt-[60px] flex gap-[12px] flex-wrap">
											<Link href="#" title="Experience Strategy & Research" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Experience Strategy & Research</Link>
											<Link href="#" title="Website Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Website Design</Link>
											<Link href="#" title="Interface Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Interface Design</Link>
											<Link href="#" title="Interaction & Motion Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Interaction & Motion Design</Link>
											<Link href="#" title="Product & App Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Product & App Design</Link>
											<Link href="#" title="Design Systems" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Design Systems</Link>
											<Link href="#" title="Dashboard & Data Experience" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Dashboard & Data Experience</Link>
											<Link href="#" title="Prototype & Validation" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Prototype & Validation</Link>
										</div>
									</div>

									<div className="services-web-development-text services-text-pointers">
										<h2 className="font-semibold ">Web & App Development</h2>
										<p className="font-normal text-18 flex flex-col gap-[18px] mt-[20px] w-[602px]">
											<span>We design digital experiences that feel effortless from the first click to the final action. Every interface is built around how your users actually think and behave - not adapted from a template or copied from a trend. </span>
											<span>From initial research through to pixel-perfect delivery, every design decision is intentional and grounded in real user insight. </span>
										</p>

										<div className="services-content-chips mt-[60px] flex gap-[12px] flex-wrap">
											<Link href="#" title="Experience Strategy & Research" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Experience Strategy & Research</Link>
											<Link href="#" title="Website Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Website Design</Link>
											<Link href="#" title="Interface Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Interface Design</Link>
											<Link href="#" title="Interaction & Motion Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Interaction & Motion Design</Link>
											<Link href="#" title="Product & App Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Product & App Design</Link>
											<Link href="#" title="Design Systems" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Design Systems</Link>
											<Link href="#" title="Dashboard & Data Experience" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Dashboard & Data Experience</Link>
											<Link href="#" title="Prototype & Validation" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Prototype & Validation</Link>
										</div>
									</div>

									<div className="services-brand-identity-text services-text-pointers">
										<h2 className="font-semibold ">Brand Identity Design</h2>
										<p className="font-normal text-18 flex flex-col gap-[18px] mt-[20px] w-[602px]">
											<span>We design digital experiences that feel effortless from the first click to the final action. Every interface is built around how your users actually think and behave - not adapted from a template or copied from a trend. </span>
											<span>From initial research through to pixel-perfect delivery, every design decision is intentional and grounded in real user insight. </span>
										</p>

										<div className="services-content-chips mt-[60px] flex gap-[12px] flex-wrap">
											<Link href="#" title="Experience Strategy & Research" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Experience Strategy & Research</Link>
											<Link href="#" title="Website Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Website Design</Link>
											<Link href="#" title="Interface Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Interface Design</Link>
											<Link href="#" title="Interaction & Motion Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Interaction & Motion Design</Link>
											<Link href="#" title="Product & App Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Product & App Design</Link>
											<Link href="#" title="Design Systems" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Design Systems</Link>
											<Link href="#" title="Dashboard & Data Experience" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Dashboard & Data Experience</Link>
											<Link href="#" title="Prototype & Validation" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Prototype & Validation</Link>
										</div>
									</div>

									<div className="services-sm-management-text services-text-pointers">
										<h2 className="font-semibold ">SM Management</h2>
										<p className="font-normal text-18 flex flex-col gap-[18px] mt-[20px] w-[602px]">
											<span>We design digital experiences that feel effortless from the first click to the final action. Every interface is built around how your users actually think and behave - not adapted from a template or copied from a trend. </span>
											<span>From initial research through to pixel-perfect delivery, every design decision is intentional and grounded in real user insight. </span>
										</p>

										<div className="services-content-chips mt-[60px] flex gap-[12px] flex-wrap">
											<Link href="#" title="Experience Strategy & Research" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Experience Strategy & Research</Link>
											<Link href="#" title="Website Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Website Design</Link>
											<Link href="#" title="Interface Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Interface Design</Link>
											<Link href="#" title="Interaction & Motion Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Interaction & Motion Design</Link>
											<Link href="#" title="Product & App Design" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Product & App Design</Link>
											<Link href="#" title="Design Systems" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Design Systems</Link>
											<Link href="#" title="Dashboard & Data Experience" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Dashboard & Data Experience</Link>
											<Link href="#" title="Prototype & Validation" className="text-18 font-normal py-[8px] px-[20px] rounded-full ">Prototype & Validation</Link>
										</div>
									</div>
								</div>
							</div>

							<div className="services-element-wrapper w-[536px] h-[536px] absolute top-[50%] translate-y-[-50%] right-[-8%]">
								<div className="services-visual-wrapper relative">
									<div className="services-ui-ux w-[100%] h-[100%] services-visuals-items object-contain flex items-center justify-center">
										<svg width="536" height="355" viewBox="0 0 300 199" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M11.0782 179.52C4.1436 167.514 70.6298 119.578 138.919 80.1692C207.209 40.7602 281.985 7.17579 288.919 19.1815C295.854 31.1871 229.368 79.1231 161.078 118.532C92.7887 157.941 18.0129 191.526 11.0782 179.52ZM287.682 19.8953C282.677 11.2292 221.994 33.8765 139.634 81.4056C102.717 102.71 69.1323 124.66 45.0582 143.226C21.9725 161.03 9.7295 174.329 12.3152 178.806C17.3209 187.472 78.0036 164.825 160.364 117.296C197.281 95.9913 230.865 74.0417 254.939 55.4754C278.025 37.6709 290.268 24.3719 287.682 19.8953Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M18.9976 174.951C14.2502 166.732 32.1778 149.188 48.0505 135.914C70.2265 117.376 101.634 96.0935 136.497 75.9747C171.359 55.8559 205.508 39.3067 232.652 29.3827C252.086 22.2743 276.25 15.5275 281.001 23.7521C285.751 31.9766 267.821 49.5148 251.948 62.7888C229.772 81.3269 198.365 102.609 163.502 122.728C128.639 142.847 94.4906 159.396 67.3463 169.32C47.9122 176.428 23.7482 183.175 18.9976 174.951ZM279.764 24.4659C278.217 21.7888 270.575 17.0358 233.141 30.7268C206.07 40.6236 172.002 57.1338 137.205 77.2143C102.409 97.2949 71.07 118.53 48.9594 137.016C18.3802 162.574 18.6773 171.566 20.2236 174.243C21.77 176.92 29.4118 181.673 66.846 167.982C93.9176 158.085 127.986 141.575 162.782 121.495C197.579 101.414 228.912 80.182 251.028 61.6932C281.607 36.1346 281.31 27.1431 279.764 24.4659Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M26.9172 170.38C22.5747 162.862 31.4527 148.429 51.914 129.739C72.1399 111.267 101.321 90.6806 134.074 71.7792C166.827 52.8778 199.254 37.9111 225.371 29.6392C251.795 21.272 268.739 20.8036 273.082 28.3216C277.424 35.8396 268.55 50.2787 248.085 68.9626C227.859 87.4351 198.678 108.021 165.925 126.922C133.172 145.824 100.746 160.791 74.6278 169.063C48.2042 177.43 31.2597 177.898 26.9172 170.38ZM271.85 29.0323C267.935 22.2539 251.154 22.9666 225.807 30.9923C199.781 39.2329 167.461 54.1534 134.79 73.0069C102.12 91.8605 73.0322 112.378 52.8797 130.786C33.2526 148.715 24.2357 162.882 28.1542 169.666C32.0727 176.45 48.8507 175.732 74.2032 167.703C100.229 159.462 132.55 144.542 165.22 125.688C197.89 106.835 226.978 86.3171 247.13 67.9089C266.758 49.9807 275.769 35.8162 271.85 29.0323Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M34.8296 165.814C29.8463 157.186 37.2846 142.185 55.7705 123.568C74.0517 105.158 100.995 85.2748 131.65 67.5844C162.304 49.8941 193 36.5075 218.095 29.8933C243.467 23.1996 260.187 24.2668 265.167 32.8888C270.147 41.5108 262.712 56.5174 244.226 75.1339C225.945 93.544 199.002 113.428 168.347 131.118C137.693 148.808 106.997 162.195 81.9021 168.809C56.5294 175.503 39.8098 174.436 34.8296 165.814ZM263.93 33.6026C259.368 25.7038 242.795 24.8533 218.458 31.2735C193.487 37.8603 162.908 51.1942 132.364 68.8209C101.82 86.4475 74.9772 106.251 56.785 124.573C39.0535 142.43 31.5041 157.201 36.0666 165.1C40.6291 172.999 57.2015 173.849 81.5425 167.434C106.519 160.844 137.092 147.514 167.636 129.887C198.181 112.26 225.023 92.4571 243.215 74.1352C260.947 56.2778 268.496 41.5071 263.93 33.6026Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M42.7489 161.243C37.1311 151.517 43.1266 135.943 59.6284 117.397C75.9617 99.0438 100.676 79.8652 129.227 63.389C157.777 46.9128 186.751 35.1086 210.82 30.1465C235.139 25.1351 251.631 27.7323 257.249 37.4583C262.866 47.1843 256.871 62.7585 240.369 81.3045C224.036 99.6577 199.321 118.836 170.771 135.312C142.22 151.789 113.246 163.593 89.1779 168.555C64.8584 173.566 48.3668 170.969 42.7489 161.243ZM256.012 38.1722C250.725 29.0203 234.777 26.6618 211.103 31.5431C187.179 36.4736 158.356 48.2202 129.938 64.6199C101.52 81.0196 76.9306 100.097 60.6964 118.341C44.6306 136.393 38.6965 151.372 43.9859 160.529C49.2754 169.687 65.2209 172.04 88.894 167.158C112.818 162.228 141.642 150.481 170.06 134.082C198.478 117.682 223.067 98.6049 239.301 80.3605C255.367 62.3089 261.301 47.3296 256.012 38.1722Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M50.6685 156.674C44.413 145.844 48.9633 129.705 63.4896 111.232C77.8751 92.9359 100.363 74.4533 126.804 59.1945C153.245 43.9357 180.503 33.7109 203.548 30.4065C226.816 27.0687 243.074 31.199 249.33 42.0289C255.585 52.8589 251.035 68.9974 236.509 87.4706C222.123 105.767 199.635 124.249 173.194 139.508C146.753 154.767 119.496 164.992 96.4506 168.296C73.1819 171.634 56.924 167.504 50.6685 156.674ZM248.093 42.7428C235.697 21.2816 181.601 29.2131 127.51 60.4286C73.418 91.6441 39.495 134.5 51.8945 155.966C64.2939 177.433 118.386 169.496 172.478 138.28C226.569 107.065 260.492 64.2094 248.093 42.7428Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M58.5821 152.106C51.6889 140.172 54.8028 123.472 67.3394 105.072C79.7739 86.8272 100.03 69.0439 124.378 54.9929C148.726 40.942 174.256 32.3028 196.287 30.6584C218.493 29.0005 234.523 34.6609 241.416 46.5948C248.31 58.5287 245.196 75.2292 232.659 93.6288C220.225 111.874 199.969 129.657 175.621 143.708C151.273 157.759 125.743 166.398 103.712 168.042C81.5051 169.7 65.4753 164.04 58.5821 152.106ZM240.179 47.3087C226.447 23.5347 174.815 27.5348 125.092 56.2295C75.3687 84.9242 46.0837 127.613 59.8191 151.392C73.5544 175.172 125.183 171.166 174.907 142.471C224.63 113.777 253.915 71.0881 240.179 47.3087Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M66.5022 147.536C58.9745 134.504 60.6433 117.239 71.2022 98.9208C81.6857 80.7272 99.7149 63.6401 121.959 50.8033C144.203 37.9666 168.025 30.9091 189.027 30.9255C210.178 30.9444 225.971 38.1323 233.498 51.1647C241.026 64.197 239.357 81.462 228.799 99.78C218.315 117.974 200.286 135.061 178.042 147.897C155.798 160.734 131.975 167.792 110.973 167.775C89.8229 167.756 74.0299 160.568 66.5022 147.536ZM232.261 51.8785C217.193 25.7917 168.031 25.8572 122.67 52.0342C77.3093 78.2113 52.6679 120.73 67.7392 146.822C82.8105 172.914 131.97 172.843 177.331 146.666C222.691 120.489 247.333 77.9708 232.261 51.8785Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M74.419 142.966C57.6196 113.882 77.8586 70.6507 119.53 46.6025C161.202 22.5543 208.778 26.6504 225.577 55.7344C242.376 84.8185 222.138 128.05 180.466 152.098C138.794 176.146 91.2183 172.05 74.419 142.966ZM224.34 56.4483C207.933 28.0432 161.237 24.1827 120.245 47.8389C79.252 71.4951 59.2489 113.847 75.6561 142.252C92.0632 170.657 138.759 174.518 179.752 150.861C220.744 127.205 240.747 84.8534 224.34 56.4483Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M82.3366 138.397C64.2013 107 79.7966 63.939 117.106 42.4084C154.415 20.8779 199.521 28.9086 217.656 60.3054C235.792 91.7023 220.196 134.763 182.887 156.294C145.578 177.824 100.472 169.794 82.3366 138.397ZM216.425 61.0161C198.682 30.2982 154.45 22.5063 117.82 43.6449C81.1901 64.7835 65.825 106.968 83.568 137.686C101.311 168.404 145.543 176.196 182.173 155.057C218.803 133.919 234.168 91.734 216.425 61.0161Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M90.2508 133.83C70.7797 100.121 81.7369 57.2267 114.683 38.2137C147.63 19.2008 190.273 31.163 209.744 64.8726C229.215 98.5823 218.258 141.476 185.311 160.489C152.365 179.502 109.722 167.54 90.2508 133.83ZM208.507 65.5865C189.428 32.5558 147.659 20.8324 115.397 39.4502C83.1358 58.0679 72.4088 100.086 91.4878 133.117C110.567 166.147 152.335 177.871 184.597 159.253C216.859 140.635 227.586 98.6172 208.507 65.5865Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M98.1703 129.26C77.3632 93.2376 83.6823 50.5104 112.261 34.0183C140.839 17.5261 181.018 33.4198 201.825 69.4423C222.632 105.465 216.313 148.192 187.735 164.684C159.157 181.176 118.977 165.283 98.1703 129.26ZM200.588 70.1561C180.173 34.8126 140.868 19.1579 112.975 35.2548C85.0813 51.3518 78.9924 93.2027 99.4073 128.546C119.822 163.89 159.127 179.545 187.021 163.448C214.914 147.351 221.003 105.5 200.588 70.1561Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M106.088 124.69C83.9448 86.3548 85.6258 43.7946 109.836 29.8233C134.046 15.852 171.761 35.677 193.904 74.0123C216.047 112.348 214.366 154.908 190.156 168.879C165.946 182.85 128.231 163.025 106.088 124.69ZM192.673 74.723C170.922 37.0666 134.081 17.4804 110.55 31.0597C87.0192 44.639 85.5684 86.3231 107.319 123.979C129.07 161.636 165.911 181.222 189.442 167.643C212.973 154.063 214.424 112.379 192.673 74.723Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M114.003 120.123C102.672 100.506 95.7135 79.9176 94.4092 62.1458C93.0969 44.1945 97.712 31.2274 107.409 25.6312C117.107 20.035 130.654 22.5205 145.546 32.6353C160.289 42.6447 174.651 58.9678 185.982 78.5853C197.313 98.2029 204.272 118.791 205.576 136.563C206.888 154.514 202.273 167.481 192.576 173.077C182.879 178.673 169.331 176.188 154.439 166.073C139.697 156.064 125.335 139.741 114.003 120.123ZM184.756 79.2928C161.669 39.3236 127.297 15.8028 108.129 26.8644C88.9608 37.9261 92.1537 79.4401 115.24 119.409C138.327 159.378 172.699 182.899 191.867 171.838C211.036 160.776 207.843 119.262 184.756 79.2928Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M121.922 115.553C109.956 94.8373 101.567 73.6983 98.3087 56.0236C95.0019 38.112 97.3754 25.8278 104.991 21.4331C112.606 17.0383 124.436 21.126 138.302 32.9442C151.981 44.6052 166.107 62.433 178.073 83.149C190.039 103.865 198.427 125.004 201.686 142.679C204.993 160.59 202.619 172.874 195.004 177.269C187.388 181.664 175.558 177.576 161.693 165.758C148.014 154.097 133.887 136.269 121.922 115.553ZM176.836 83.8628C164.95 63.2849 150.934 45.5847 137.376 34.0306C124.004 22.6339 112.757 18.5998 105.705 22.6695C98.6529 26.7391 96.5246 38.4919 99.7131 55.7652C102.945 73.2787 111.272 94.2614 123.159 114.839C135.045 135.417 149.061 153.118 162.619 164.672C175.991 176.068 187.238 180.102 194.29 176.033C201.342 171.963 203.47 160.21 200.281 142.937C197.05 125.424 188.722 104.441 176.836 83.8628Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M129.845 110.984C103.248 64.9373 91.2676 23.7621 102.572 17.2386C113.876 10.715 143.561 41.6731 170.158 87.7196C196.755 133.766 208.736 174.941 197.431 181.465C186.127 187.988 156.442 157.03 129.845 110.984ZM168.921 88.4335C156.375 66.7129 142.558 47.4702 130.013 34.242C117.856 21.4302 108.115 15.681 103.283 18.4695C98.4508 21.258 98.5558 32.5684 103.583 49.4944C108.769 66.962 118.536 88.5494 131.082 110.27C143.628 131.991 157.448 151.239 169.99 164.462C182.147 177.273 191.888 183.022 196.72 180.234C201.552 177.445 201.447 166.135 196.42 149.209C191.234 131.741 181.467 110.154 168.921 88.4335Z" fill="#A4ABC7" fillOpacity="0.5" />
											<path d="M137.759 106.413C124.521 83.4946 113.286 61.2528 106.12 43.7726C98.6049 25.4339 96.5925 15.0917 100.143 13.0426C103.694 10.9934 111.645 17.901 123.78 33.581C135.342 48.5244 148.999 69.3759 162.234 92.2888C175.469 115.202 186.706 137.449 193.873 154.929C201.388 173.268 203.4 183.61 199.849 185.659C196.298 187.708 188.347 180.801 176.212 165.121C164.65 150.177 150.993 129.326 137.759 106.413ZM161.002 92.9994C147.796 70.1362 134.175 49.3455 122.655 34.4509C109.737 17.7585 102.929 13.0841 100.863 14.276C98.7978 15.4679 99.4379 23.702 107.447 43.2276C114.587 60.6494 125.795 82.8328 139.001 105.696C152.207 128.559 165.829 149.35 177.348 164.245C190.266 180.937 197.075 185.611 199.14 184.42C201.206 183.228 200.566 174.994 192.557 155.468C185.417 138.046 174.208 115.863 161.002 92.9994Z" fill="#A4ABC7" fillOpacity="0.5" />
										</svg>
									</div>

									<div className="services-web-development w-[100%] h-[100%] services-visuals-items object-contain flex items-center justify-center">
										<svg viewBox="0 0 234 245" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M233.306 228.272C232.607 226.477 226.88 210.784 225.429 206.681C224.713 204.659 222.511 198.587 220.536 193.196C218.561 187.8 216.545 182.241 216.05 180.831C215.561 179.426 213.434 173.587 211.337 167.853C209.234 162.119 207.399 156.991 207.247 156.455C207.102 155.918 206.705 154.817 206.367 154.001C205.429 151.746 198.776 133.396 198.776 133.069C198.776 132.912 198.415 131.892 197.967 130.802C197.524 129.713 196.656 127.446 196.038 125.756C191.692 113.833 190.399 110.214 190.399 109.981C190.399 109.835 190.073 108.909 189.671 107.924C189.269 106.945 187.655 102.609 186.082 98.2969C184.509 93.9846 182.954 89.7598 182.622 88.9031C182.289 88.0465 182.021 87.1724 182.021 86.9626C182.021 86.7528 181.613 85.599 181.112 84.4044C180.075 81.9277 174.174 65.5701 173.952 64.562C173.871 64.1949 173.58 63.3907 173.306 62.7672C172.898 61.8406 167.667 47.3944 166.373 43.6124C166.181 43.053 165.762 41.8992 165.447 41.06C165.132 40.215 163.227 34.9295 161.217 29.3119C152.467 4.84256 150.684 -0.0116339 150.475 2.09118e-05C150.352 0.00584833 149.927 0.442859 149.525 0.973155C143.123 9.41126 138.689 15.1921 138.054 15.9322C137.617 16.4392 134.757 20.0696 131.692 24.0031C128.628 27.9366 125.529 31.9168 124.806 32.8434C123.792 34.1429 115.916 44.2127 108.884 53.1869C108.605 53.5482 105.441 57.6099 101.853 62.2194C98.2638 66.8289 95.0713 70.9197 94.7567 71.3102C94.0518 72.1843 80.4951 89.5558 79.3824 91.0126C78.9454 91.5837 75.4966 95.9951 71.7215 100.814C67.9464 105.628 64.6781 109.812 64.4509 110.115C64.2295 110.412 57.5123 119.025 49.531 129.252C41.5438 139.479 31.7157 152.078 27.69 157.247C23.6644 162.416 19.7844 167.381 19.0678 168.284C17.9551 169.689 3.83927 187.771 2.25465 189.828C1.73033 190.504 0 195.02 0 195.708C0 195.877 0.705024 197.299 1.56142 198.872L3.12269 201.734L7.04928 204.88C10.9176 207.981 11.0575 208.068 16.9823 211.215C22.2663 214.018 23.9091 214.77 30.6496 217.474C61.136 229.688 109.234 239.967 151.383 243.289C162.971 244.198 162.93 244.198 173.446 244.495C178.223 244.629 182.954 244.705 183.967 244.664C184.981 244.624 189.164 244.46 193.265 244.303C199.912 244.047 201.485 243.913 207.771 243.091C214.698 242.188 214.914 242.141 220.163 240.655L225.505 239.14L228.832 236.92L232.158 234.705L233.766 229.461L233.318 228.301L233.306 228.272ZM231.914 228.825C231.721 228.808 227.713 228.33 223.006 227.753L214.448 226.704L211.634 222.514H212.403C213.597 222.532 229.228 223.686 229.292 223.767C229.327 223.808 230.009 224.968 230.807 226.343C231.896 228.225 232.17 228.837 231.908 228.82L231.914 228.825ZM160.879 218.039L153.527 217.491L151.71 216.291L152.514 216.221C152.956 216.186 156.312 216.186 159.971 216.221L166.624 216.291L168.296 217.386C169.216 217.992 169.968 218.517 169.968 218.563C169.968 218.691 168.511 218.61 160.879 218.039ZM170.9 219.56C171.349 219.63 171.733 219.939 172.281 220.679C173.003 221.646 173.015 221.698 172.578 221.681C172.321 221.669 168.389 221.203 163.839 220.65C155.683 219.653 155.561 219.63 155.118 219.094C154.867 218.796 154.692 218.522 154.727 218.488C154.803 218.412 170.02 219.426 170.9 219.56ZM151.075 217.38C148.115 217.2 135.625 216.203 135.24 216.116C134.961 216.057 138.054 216.028 142.121 216.058L149.513 216.11L150.498 216.757C151.139 217.176 151.343 217.392 151.075 217.375V217.38ZM152.962 218.691C153.213 218.925 153.423 219.193 153.423 219.286C153.423 219.461 153.143 219.519 152.997 219.373C152.951 219.327 149.187 218.843 144.637 218.301C140.087 217.759 136.528 217.287 136.732 217.246C136.936 217.205 140.565 217.421 144.8 217.718C151.902 218.225 152.537 218.301 152.962 218.691ZM150.154 215.166C149.17 214.956 146.921 213.884 147.294 213.802C147.463 213.767 150.3 213.558 153.603 213.33L159.604 212.928L162.08 214.07C163.443 214.7 164.596 215.247 164.643 215.288C164.806 215.434 150.865 215.317 150.154 215.166ZM156.213 210.772C152.898 209.607 152.024 209.245 152.525 209.234C152.63 209.234 154.902 208.832 157.576 208.336L162.441 207.445L167.282 209.169C169.945 210.119 172.211 210.982 172.316 211.087C172.438 211.203 172.246 211.279 171.809 211.279C171.424 211.279 168.942 211.419 166.303 211.582C163.664 211.751 161.124 211.92 160.664 211.961C160.029 212.019 158.945 211.728 156.219 210.766L156.213 210.772ZM91.1156 208.016C84.9869 206.326 83.9556 205.988 84.4741 205.842C85.983 205.422 87.02 205.656 92.9507 207.736C96.1549 208.861 98.9105 209.834 99.0794 209.898C99.2659 209.974 99.1842 210.02 98.8755 210.014C98.5958 210.014 95.1005 209.111 91.1098 208.01L91.1156 208.016ZM96.9356 210.626C96.5336 210.626 81.4855 207.357 80.8913 207.147C80.6932 207.077 80.8389 206.92 81.3399 206.675C82.0681 206.32 82.1263 206.326 83.4838 206.757C84.2528 207.002 87.5909 207.934 90.9058 208.837C94.2207 209.735 97.0229 210.51 97.1394 210.551C97.2501 210.597 97.157 210.632 96.9356 210.626ZM141.695 126.519C141.777 126.601 141.579 130.901 141.258 136.07C140.693 145.254 140.67 145.476 140.262 145.458C139.633 145.429 122.08 142.387 121.981 142.294C121.864 142.177 125.639 123.955 125.814 123.798C125.977 123.652 141.491 126.309 141.695 126.519ZM126.164 122.16C126.082 122.079 129.659 104.404 129.781 104.282C129.851 104.212 142.878 106.455 142.977 106.554C143.052 106.63 142.394 118.384 142.045 123.151C141.923 124.806 141.911 124.835 141.392 124.818C140.658 124.788 126.286 122.283 126.164 122.16ZM140.443 147.142C140.548 147.247 139.784 160.72 139.412 165.353C139.342 166.221 139.225 166.926 139.149 166.921C137.611 166.705 117.763 163.22 117.699 163.15C117.606 163.057 121.456 144.071 121.602 143.932C121.707 143.827 140.297 146.991 140.443 147.137V147.142ZM139.429 190.627L150.958 193.191C157.297 194.601 162.528 195.796 162.581 195.848C162.633 195.9 162.453 196.029 162.185 196.134C161.917 196.238 160.32 196.885 158.642 197.567C156.965 198.249 155.444 198.803 155.269 198.797C154.995 198.785 138.2 195.055 136.603 194.648L136.027 194.502L136.854 193.54C137.308 193.01 138.077 192.136 138.555 191.6L139.423 190.621L139.429 190.627ZM128.29 166.647L139.126 168.471V169.287C139.132 170.475 138.106 187.556 137.984 188.342C137.897 188.908 137.798 189.001 137.326 188.983C136.551 188.954 113.353 184.956 113.224 184.828C113.091 184.688 117.075 165.248 117.285 165.009C117.384 164.899 121.847 165.563 128.284 166.647H128.29ZM137.343 190.289C137.46 190.329 136.796 191.204 135.869 192.235C134.675 193.569 134.058 194.106 133.743 194.088C133.05 194.047 113.789 190.702 113.69 190.603C113.58 190.493 112.945 186.308 113.027 186.227C113.085 186.169 136.936 190.143 137.349 190.283L137.343 190.289ZM93.143 201.687C95.1762 202.934 96.8364 203.995 96.8364 204.041C96.8364 204.088 95.7587 204.123 94.4363 204.117L92.036 204.105L81.7593 199.531L89.4494 199.42L93.143 201.687ZM86.251 196.18C84.1945 194.91 82.5399 193.838 82.5749 193.803C82.6506 193.727 95.4208 194.514 95.7179 194.613C95.8344 194.653 96.8773 195.702 98.0366 196.955C99.7785 198.832 100.064 199.222 99.662 199.199C99.3999 199.181 97.1103 199.018 94.5819 198.832L89.9853 198.494L86.2452 196.18H86.251ZM92.2283 199.677C92.2865 199.618 94.2906 199.688 96.685 199.834L101.031 200.096L105.249 204.537L104.462 204.508C102.82 204.449 99.4291 204.146 99.1494 204.041C98.4969 203.791 92.1292 199.776 92.2283 199.677ZM103.863 201.081L103.28 200.382L104.602 200.516C105.331 200.592 107.597 200.848 109.642 201.093L113.358 201.53L113.586 202.981C113.714 203.779 113.865 204.688 113.924 204.997C114.052 205.661 114.349 205.65 110.277 205.114L107.276 204.717L105.861 203.249C105.08 202.439 104.183 201.466 103.863 201.081ZM113.16 200.195C113.178 200.743 113.766 200.761 107.352 200.003L102.243 199.397L100.157 197.217C99.0096 196.017 98.0658 194.986 98.0658 194.927C98.0541 194.787 111.471 196.303 112.147 196.518C112.589 196.658 112.683 196.862 112.898 198.208C113.032 199.047 113.149 199.945 113.16 200.195ZM104.701 194.717C101.218 194.286 98.0774 193.925 97.722 193.919C97.1627 193.913 96.7607 193.581 94.8207 191.518C93.5798 190.201 92.5836 189.111 92.6069 189.088C92.671 189.036 111.418 191.244 111.663 191.338C111.855 191.407 112.362 194.199 112.362 195.189C112.362 195.662 112.281 195.656 104.701 194.717ZM111.506 190.417C111.36 190.405 106.81 189.863 101.398 189.211L91.5584 188.028L89.5484 185.936C88.4473 184.788 87.4162 183.663 87.2589 183.441C86.9909 183.063 87.0142 183.045 87.5676 183.15C87.8939 183.214 93.1196 183.826 99.1901 184.514C105.255 185.195 110.417 185.796 110.65 185.848C111.028 185.924 111.11 186.174 111.331 187.829C111.465 188.873 111.622 189.881 111.681 190.079C111.745 190.294 111.681 190.428 111.512 190.417H111.506ZM90.3174 188.843L92.2983 190.883C93.3877 192.008 94.3547 193.057 94.4421 193.214C94.6519 193.587 93.4168 193.569 86.1404 193.086L80.6583 192.725L78.8873 191.641C73.7955 188.523 72.6537 187.789 72.9333 187.783C73.0964 187.783 77.0754 188.022 81.7768 188.313L90.3116 188.849L90.3174 188.843ZM80.1281 193.698L83.8334 195.976C85.8724 197.229 87.5794 198.29 87.626 198.33C87.6726 198.371 85.7907 198.406 83.4371 198.4H79.1669L68.7678 193.808L80.1281 193.698ZM83.2333 201.238C85.4937 202.235 87.824 203.266 88.424 203.523C89.0183 203.779 89.4319 204.053 89.3445 204.135C89.2513 204.216 88.4473 204.327 87.5443 204.385L85.9072 204.484L72.8342 199.951L79.1261 199.426L83.2333 201.244V201.238ZM88.7736 205.329C88.7037 205.259 89.4086 205.154 90.3407 205.102C91.8846 205.009 92.1351 205.05 93.1546 205.556C93.7722 205.865 96.0267 206.873 98.1589 207.806C100.291 208.738 102.08 209.531 102.126 209.572C102.173 209.612 101.899 209.636 101.515 209.624C100.874 209.607 89.0649 205.621 88.7736 205.329ZM99.0678 207.171L94.2848 205.049L98.6542 204.933L99.6329 205.621C100.169 205.999 101.736 206.99 103.117 207.823C104.492 208.657 105.622 209.408 105.622 209.49C105.622 209.682 105.08 209.659 104.375 209.449C104.084 209.362 101.695 208.336 99.0619 207.171H99.0678ZM104.392 207.369L100.816 205.131L103.064 205.253C104.299 205.323 105.523 205.422 105.779 205.475C106.199 205.562 108.442 207.742 109.519 209.111L109.945 209.647L108.96 209.63C108.075 209.612 107.614 209.385 104.398 207.375L104.392 207.369ZM108.418 217.206C108.622 217.206 109.158 217.153 109.607 217.095L110.422 216.984L109.735 217.299C108.942 217.666 108.354 217.707 108.174 217.409C108.104 217.299 108.214 217.206 108.418 217.206ZM110.434 210.673C110.883 210.673 111.256 210.871 111.751 211.384C112.625 212.287 112.368 212.287 110.935 211.384C109.851 210.702 109.834 210.679 110.434 210.673ZM111.768 217.771C113.085 217.211 113.452 217.136 113.277 217.439C113.189 217.59 112.98 217.876 112.811 218.074C112.485 218.458 112.1 218.499 111.442 218.237C111.081 218.091 111.116 218.039 111.768 217.765V217.771ZM113.096 210.807L113.778 210.941C114.151 211.017 114.535 211.075 114.629 211.075C114.722 211.075 114.856 211.39 114.932 211.78C115.153 212.969 114.943 212.992 114.005 211.873L113.102 210.801L113.096 210.807ZM114.355 210.23C112.158 209.997 112.234 210.038 110.23 207.899C109.181 206.78 108.407 205.836 108.5 205.801C108.663 205.737 114.063 206.355 114.116 206.436C114.162 206.518 114.617 209.758 114.617 210.003C114.617 210.143 114.5 210.248 114.361 210.23H114.355ZM114.454 195.865C114.314 195.726 113.766 191.827 113.871 191.722C113.97 191.623 132.461 194.618 133.172 194.846C133.463 194.939 133.044 195.493 131.116 197.538C130.562 198.127 130.043 198.598 129.968 198.587C128.255 198.325 114.5 195.906 114.454 195.865ZM135.281 195.475C135.52 195.324 138.042 195.807 144.719 197.287C149.729 198.4 153.83 199.356 153.824 199.42C153.824 199.478 152.275 200.149 150.393 200.912C148.505 201.67 146.921 202.287 146.874 202.276C146.14 202.159 132.263 198.971 132.199 198.907C132.094 198.802 134.809 195.766 135.281 195.475ZM152.729 201.238L156.108 199.851L164.113 202.112C168.517 203.354 172.187 204.438 172.269 204.513C172.351 204.589 170.236 205.044 167.567 205.516C164.899 205.988 162.441 206.372 162.103 206.361C161.357 206.337 149.094 202.87 149.24 202.724C149.298 202.666 150.865 201.996 152.723 201.233L152.729 201.238ZM169.717 209.175C166.822 208.138 164.457 207.246 164.457 207.182C164.457 207.118 166.775 206.646 169.612 206.133L174.768 205.195L181.305 207.549C184.899 208.843 187.929 209.985 188.034 210.084C188.15 210.189 187.929 210.259 187.503 210.259C187.107 210.259 184.765 210.393 182.301 210.556C179.842 210.72 177.18 210.9 176.394 210.959C175.001 211.058 174.832 211.017 169.706 209.175H169.717ZM174.057 204.111C173.778 204.024 170.055 202.963 165.785 201.763C161.515 200.562 157.903 199.513 157.751 199.438C157.594 199.356 159.009 198.68 161.153 197.812L164.824 196.326L175.071 199.251C181.753 201.157 185.191 202.229 184.946 202.322C184.742 202.404 182.412 202.847 179.773 203.313C177.134 203.779 174.879 204.181 174.768 204.216C174.658 204.251 174.331 204.199 174.052 204.111H174.057ZM163.286 194.712C162.866 194.694 140.087 189.578 139.953 189.479C139.813 189.374 141.031 169.403 141.194 169.147C141.369 168.867 161.596 173.395 161.911 173.785C162.027 173.931 162.423 178.494 162.79 183.931C163.157 189.368 163.501 194.018 163.554 194.275C163.624 194.618 163.554 194.729 163.286 194.717V194.712ZM161.864 172.031C161.625 172.008 141.276 167.317 141.229 167.276C141.142 167.2 142.383 147.673 142.476 147.579C142.563 147.492 160.384 151.548 160.483 151.676C160.501 151.699 160.804 155.901 161.159 161.017C161.514 166.134 161.852 170.709 161.917 171.186C161.981 171.664 161.951 172.049 161.864 172.037V172.031ZM160.012 149.963C159.749 149.951 146.402 146.868 142.901 146.012C142.625 145.946 142.678 142.764 143.058 136.467C143.373 131.274 143.67 126.974 143.728 126.921C143.833 126.816 158.747 130.301 158.916 130.476C158.992 130.552 160.326 148.174 160.367 149.625C160.367 149.841 160.233 149.975 160.017 149.969L160.012 149.963ZM158.753 128.739C158.66 128.833 147.871 126.35 144.218 125.394C143.775 125.278 143.705 125.161 143.758 124.59C143.793 124.223 144.049 120.115 144.329 115.459C144.608 110.803 144.859 106.974 144.888 106.945C144.969 106.863 157.291 109.841 157.419 109.975C157.483 110.039 157.833 114.258 158.2 119.357C158.567 124.45 158.811 128.675 158.747 128.745L158.753 128.739ZM143.734 95.9601C143.443 100.663 143.204 104.62 143.204 104.76C143.204 105.109 143.303 105.121 136.26 103.88C132.834 103.279 130.003 102.784 129.968 102.772C129.933 102.772 129.956 102.679 130.02 102.574C130.084 102.469 130.911 98.6466 131.861 94.072C132.811 89.4975 133.644 85.698 133.714 85.6281C133.836 85.5057 144.02 87.1549 144.189 87.3298C144.229 87.3705 144.031 91.2574 143.734 95.9543V95.9601ZM128.558 101.187C128.29 102.382 128.191 102.563 127.812 102.545C125.505 102.423 115.328 101.187 115.357 101.03C115.427 100.628 121.206 84.4801 121.334 84.3344C121.462 84.1829 131.57 85.1386 131.75 85.3134C131.832 85.395 129.542 96.776 128.558 101.187ZM127.83 104.072C127.923 104.165 124.637 120.435 124.288 121.624C124.229 121.822 124.031 121.974 123.839 121.962C122.977 121.904 108.576 120.307 108.535 120.266C108.459 120.191 114.629 102.895 114.786 102.755C114.937 102.615 127.661 103.909 127.83 104.078V104.072ZM122.936 123.337C123.414 123.401 123.804 123.565 123.81 123.693C123.81 123.821 122.965 127.993 121.928 132.97L120.041 142.014L119.318 141.991C117.949 141.944 101.777 140.074 101.649 139.945C101.544 139.841 107.742 122.049 107.958 121.828C108.028 121.758 120.92 123.058 122.936 123.343V123.337ZM102.802 130.954C101.037 135.831 99.5047 139.846 99.3882 139.864C99.0736 139.922 82.4526 139.13 82.3769 139.054C82.3361 139.013 84.3111 134.963 86.7638 130.045L91.2204 121.105L95.4091 121.234C103.851 121.496 106.03 121.618 106.024 121.851C106.018 121.974 104.567 126.07 102.808 130.948L102.802 130.954ZM100.915 141.74C101.054 141.589 119.423 143.483 119.592 143.663C119.65 143.727 116.155 160.726 115.735 162.381C115.636 162.777 115.491 162.853 114.856 162.83C114.127 162.806 94.3372 160.569 94.2207 160.499C94.1333 160.441 100.74 141.933 100.909 141.746L100.915 141.74ZM115.194 164.596C115.258 164.66 111.5 183.109 111.209 184.158C111.133 184.432 110.906 184.508 110.253 184.49C109.397 184.461 86.7753 181.839 86.6646 181.751C86.6064 181.705 93.5159 162.218 93.6207 162.136C93.7081 162.072 115.112 164.514 115.2 164.601L115.194 164.596ZM87.2589 185.557L89.3212 187.777L87.9173 187.748C87.1482 187.73 83.344 187.509 79.4698 187.253C75.5957 186.996 72.1002 186.781 71.6982 186.769C71.1505 186.757 70.0029 186.151 66.8977 184.251C64.0547 182.503 62.9478 181.728 63.2508 181.687C64.1887 181.553 84.6722 182.899 84.9285 183.115C85.0742 183.237 86.1228 184.333 87.2589 185.557ZM74.1217 190.015C76.2947 191.349 78.124 192.497 78.188 192.567C78.258 192.631 75.5607 192.684 72.1992 192.678L66.088 192.666L55.2986 187.888L58.8581 187.76C60.8156 187.69 64.1596 187.62 66.2976 187.608L70.1776 187.585L74.1275 190.015H74.1217ZM71.535 196.087C74.5645 197.421 76.9239 198.534 76.7783 198.564C76.6326 198.593 75.1354 198.738 73.4576 198.884L70.399 199.152L64.5674 197.159C57.0579 194.595 57.0404 194.589 57.4075 194.461C57.5764 194.403 59.5806 194.199 61.8701 194.007L66.0238 193.657L71.5292 196.081L71.535 196.087ZM70.6203 200.184L76.8366 202.293C85.016 205.073 84.3168 204.746 82.8487 205.067C82.1729 205.213 81.4855 205.329 81.3166 205.323C80.4544 205.288 66.2044 201.174 66.5364 201.052C66.7462 200.982 67.7483 200.755 68.7678 200.551L70.6262 200.178L70.6203 200.184ZM88.1561 209.618C91.7506 210.399 94.879 211.087 95.1004 211.139C95.4208 211.215 95.4034 211.238 94.9955 211.238C94.5295 211.238 79.5281 208.75 79.0562 208.593C78.9397 208.552 78.9805 208.342 79.1611 208.086C79.4582 207.666 79.5164 207.66 80.5417 207.922C81.1359 208.074 84.5557 208.837 88.1561 209.624V209.618ZM87.3347 210.859C91.8264 211.629 95.2286 212.258 94.8907 212.258C94.5528 212.258 90.8417 211.827 86.6413 211.308C79.3183 210.399 78.9979 210.341 78.8348 209.904C78.7183 209.583 78.7415 209.449 78.9163 209.455C79.0561 209.455 82.843 210.096 87.3347 210.865V210.859ZM80.3902 211.361C80.7281 211.425 84.1304 211.85 87.9521 212.305C91.7738 212.753 95.0829 213.155 95.3043 213.196C96.5044 213.406 92.3157 213.22 86.9676 212.823L80.8796 212.375L80.3262 211.809L79.7786 211.244L80.3902 211.366V211.361ZM97.1452 214.402C97.5938 214.443 94.9315 214.496 91.2204 214.507L84.4799 214.536L83.5071 213.995C82.9711 213.697 82.5574 213.429 82.5866 213.4C82.6332 213.354 95.2577 214.216 97.1394 214.397L97.1452 214.402ZM91.1971 215.469C93.7721 215.527 96.8249 215.574 97.9901 215.574C99.1552 215.574 100.105 215.65 100.105 215.743C100.105 215.836 98.1997 216.023 95.8636 216.162C93.5333 216.296 91.0281 216.454 90.2941 216.5C89.1231 216.582 88.8202 216.518 87.7424 215.976L86.519 215.364L91.1971 215.469ZM97.1452 217.031C102.254 216.687 103.373 216.681 103.373 216.99C103.373 217.071 101.695 217.433 99.6445 217.794C97.5938 218.155 95.6888 218.493 95.4033 218.54C94.9955 218.604 91.3428 217.479 91.7273 217.409C91.7856 217.398 94.2207 217.229 97.1394 217.031H97.1452ZM101.952 218.429C104.503 217.975 105.989 217.806 106.496 217.899C106.915 217.975 107.253 218.103 107.253 218.184C107.253 218.26 106.036 218.814 104.544 219.402C103.059 219.997 101.794 220.469 101.736 220.457C99.9008 220.014 97.6521 219.292 97.8676 219.21C98.0307 219.152 99.866 218.796 101.946 218.429H101.952ZM107.323 219.589C109.385 218.767 109.607 218.721 110.539 218.901C111.092 219.012 111.541 219.193 111.541 219.309C111.541 219.426 111.063 220.032 110.475 220.661C109.886 221.29 109.315 221.862 109.199 221.932C109.082 222.001 107.888 221.803 106.536 221.5C103.74 220.865 103.664 221.052 107.323 219.589ZM112.257 220.993C113.51 219.566 113.795 219.467 115.52 219.834C116.166 219.974 116.132 219.892 116.522 222.462C116.621 223.097 116.586 223.324 116.394 223.307C115.834 223.254 111.226 222.45 111.156 222.392C111.116 222.357 111.611 221.728 112.252 220.993H112.257ZM115.566 219.024C114.902 218.989 114.407 218.831 114.407 218.662C114.407 218.458 115.607 217.316 115.706 217.427C115.747 217.474 115.834 217.858 115.898 218.278C116.003 218.971 115.974 219.041 115.572 219.018L115.566 219.024ZM114.879 199.519C114.745 198.738 114.628 197.8 114.623 197.433C114.611 196.844 114.663 196.78 115.071 196.874C115.322 196.932 118.608 197.485 122.377 198.109C126.14 198.733 129.286 199.257 129.368 199.286C129.449 199.309 128.867 200.067 128.074 200.964C127.282 201.862 126.525 202.654 126.397 202.719C126.268 202.783 123.676 202.41 120.646 201.891L115.135 200.941L114.891 199.525L114.879 199.519ZM129.811 201.419C131.081 199.991 131.488 199.653 131.838 199.741C132.077 199.799 135.211 200.492 138.806 201.279C142.394 202.066 145.371 202.754 145.424 202.8C145.476 202.853 145.295 202.975 145.027 203.08C144.759 203.185 143.257 203.785 141.684 204.414C140.116 205.044 138.782 205.556 138.724 205.545C138.613 205.527 131.646 203.983 129.432 203.482L128.22 203.208L129.811 201.425V201.419ZM141.41 205.854C141.672 205.72 143.193 205.084 144.789 204.438L147.696 203.26L153.673 204.939C156.959 205.865 159.72 206.681 159.802 206.757C159.883 206.833 157.768 207.287 155.1 207.765C152.432 208.243 150.113 208.622 149.944 208.604C149.775 208.587 147.678 208.016 145.284 207.334C141.433 206.232 140.985 206.063 141.404 205.854H141.41ZM150.405 209.624L153.754 210.807C155.595 211.46 157.104 212.042 157.104 212.101C157.104 212.159 154.459 212.375 151.232 212.573C147.999 212.771 145.173 212.922 144.952 212.911C144.62 212.899 142.324 212.124 140.967 211.559C140.798 211.489 142.854 211.023 145.534 210.527L150.411 209.624H150.405ZM146.082 214.525L147.399 215.131L140.553 215.119C136.79 215.119 133.434 215.044 133.096 214.968C132.508 214.828 132.514 214.816 133.405 214.688C133.912 214.612 136.673 214.414 139.546 214.234L144.765 213.913L146.082 214.519V214.525ZM142.179 221.897C138.421 220.871 135.298 219.979 135.24 219.921C135.182 219.857 135.368 219.857 135.648 219.909C137.174 220.207 150.714 223.173 150.97 223.272C151.18 223.348 151.046 223.47 150.562 223.656C149.805 223.942 149.263 224.018 149.106 223.86C149.053 223.808 145.936 222.928 142.179 221.897ZM147.16 224.373C146.292 224.688 144.928 224.729 144.334 224.461C143.996 224.309 141.351 223.371 138.456 222.386C135.561 221.395 133.289 220.55 133.411 220.51C133.824 220.37 147.55 224.227 147.16 224.373ZM143.524 220.778C139.598 219.927 136.335 219.181 136.271 219.111C136.213 219.041 136.388 219.041 136.673 219.111C136.953 219.181 140.81 219.84 145.243 220.58C149.677 221.32 153.347 221.972 153.399 222.019C153.452 222.071 153.318 222.246 153.102 222.415C152.659 222.753 152.17 222.776 151.279 222.508C150.941 222.404 147.451 221.629 143.524 220.784V220.778ZM152.945 221.081C152.624 220.988 148.878 220.335 144.62 219.635C140.361 218.936 136.912 218.33 136.959 218.284C137.029 218.214 151.226 219.874 153.271 220.189C153.912 220.288 154.034 220.387 154.034 220.801C154.034 221.325 153.877 221.366 152.939 221.081H152.945ZM167.62 215.568L166.088 214.886C165.243 214.513 163.915 213.895 163.128 213.517L161.701 212.829L162.517 212.765C162.965 212.73 165.907 212.52 169.053 212.31L174.774 211.92L178.246 213.563C180.157 214.467 181.858 215.288 182.027 215.387C182.208 215.492 179.266 215.568 174.978 215.568H167.62ZM177.122 211.903C177.122 211.774 188.424 210.993 189.991 211.011C190.48 211.011 192.234 211.774 195.508 213.383L200.309 215.749L185.19 215.778L183.251 214.886C178.765 212.829 177.122 212.031 177.122 211.903ZM183.722 207.544C179.994 206.168 176.895 204.997 176.842 204.939C176.79 204.88 179.196 204.391 182.202 203.861L187.661 202.887L195.724 205.877C200.157 207.52 203.857 208.931 203.944 209.012C204.026 209.094 201.497 209.321 198.328 209.519C195.153 209.717 192.094 209.915 191.535 209.962C190.626 210.038 189.746 209.764 183.734 207.549L183.722 207.544ZM186.391 201.256C186 201.238 165.569 195.3 165.453 195.172C165.325 195.032 163.781 174.287 163.892 174.176C163.95 174.118 182.452 179.549 182.54 179.648C182.569 179.677 183.431 184.35 184.468 190.026C185.505 195.702 186.397 200.551 186.461 200.807C186.519 201.058 186.49 201.262 186.397 201.256H186.391ZM182.074 177.952C181.992 177.94 177.827 176.711 172.828 175.219C164.305 172.672 163.734 172.474 163.682 172.02C163.501 170.458 162.26 152.311 162.33 152.241C162.377 152.195 166.018 153.255 170.422 154.596L178.433 157.037L180.315 167.247C181.352 172.865 182.202 177.573 182.208 177.713C182.214 177.853 182.15 177.958 182.068 177.952H182.074ZM177.792 155.272C177.233 155.242 162.388 150.65 162.22 150.458C162.045 150.26 160.687 131.204 160.839 131.053C160.949 130.942 174.081 135.027 174.325 135.254C174.413 135.336 175.263 139.672 176.219 144.887C177.168 150.103 177.996 154.578 178.054 154.829C178.135 155.178 178.071 155.283 177.798 155.272H177.792ZM167.317 131.478L160.676 129.386L160.542 128.186C160.239 125.424 159.277 110.744 159.394 110.622C159.499 110.517 170.323 113.903 170.539 114.107C170.574 114.136 171.378 118.419 172.333 123.623C173.288 128.827 174.04 133.192 174.011 133.326C173.97 133.483 171.686 132.854 167.311 131.478H167.317ZM168.238 111.863C167.451 111.595 165.033 110.808 162.866 110.115C160.448 109.34 158.951 108.763 159.004 108.623C159.05 108.495 158.8 104.416 158.456 99.5557C158.107 94.6956 157.862 90.7154 157.909 90.7154C158.276 90.7154 166.915 93.6234 166.915 93.7516C166.915 93.839 167.649 97.9065 168.546 102.784C169.443 107.667 170.178 111.822 170.183 112.021C170.183 112.469 170.003 112.458 168.243 111.863H168.238ZM162.004 90.6164L157.611 89.1479L157.559 87.8367C157.53 87.1141 157.279 83.4137 157 79.6026C156.72 75.7973 156.487 72.4232 156.487 72.1085V71.5375L159.872 72.6679C161.736 73.2915 163.285 73.9033 163.32 74.0315C163.355 74.1597 164.095 78.2448 164.969 83.1107C165.837 87.9766 166.519 91.9858 166.472 92.0208C166.426 92.0557 164.416 91.4264 162.004 90.6164ZM156.778 99.2935L157.413 108.291L156.901 108.268C156.621 108.256 153.807 107.609 150.649 106.828L144.911 105.412L144.992 104.352C145.039 103.769 145.284 99.8179 145.54 95.5756C145.797 91.3332 146.041 87.8251 146.088 87.7785C146.187 87.6794 155.864 90.0336 156.027 90.1968C156.091 90.2609 156.423 94.3576 156.778 99.3051V99.2935ZM145.435 67.2892C145.331 67.3708 137.675 66.0364 137.547 65.9081C137.495 65.8557 137.553 65.6284 137.676 65.407C137.798 65.1797 138.584 61.6658 139.435 57.5982C140.279 53.5307 141.014 50.1333 141.066 50.0518C141.118 49.9702 142.196 50.075 143.46 50.2848C146.764 50.8326 146.641 50.7918 146.542 51.3221C146.496 51.5785 146.245 55.2615 145.983 59.5038C145.721 63.7462 145.476 67.2543 145.429 67.2892H145.435ZM145.395 68.7344C145.395 68.7344 145.208 72.2484 144.934 76.5199C144.661 80.7855 144.439 84.6258 144.433 85.0454C144.433 85.9952 144.847 86.0011 138.654 84.923C134.605 84.2179 133.819 84.0256 133.923 83.7692C133.993 83.6002 134.792 79.8706 135.7 75.4884C136.609 71.1062 137.378 67.4874 137.407 67.4466C137.454 67.3883 145.231 68.6412 145.389 68.7344H145.395ZM132.281 83.3088C132.187 83.6993 132.042 83.7633 131.308 83.74C129.222 83.6701 121.87 82.8076 121.905 82.6328C121.998 82.1724 127.62 66.6016 127.731 66.4909C127.876 66.3452 135.287 67.0212 135.497 67.196C135.607 67.2892 132.997 80.3893 132.292 83.3088H132.281ZM123.163 74.1423C121.689 78.2565 120.39 81.8752 120.285 82.1841C120.093 82.726 120.047 82.7435 118.73 82.7027C117.984 82.6794 115.788 82.627 113.848 82.5979L110.323 82.5396L118.491 66.1995H122.167C124.783 66.1995 125.843 66.2636 125.843 66.4326C125.843 66.5608 124.637 70.034 123.163 74.1481V74.1423ZM110.469 83.8391C110.888 83.9091 112.986 83.9673 115.118 83.9731C117.25 83.9731 119.12 84.0547 119.26 84.1479C119.464 84.2761 118.811 86.2983 116.504 92.7259L113.487 101.141L112.257 101.112C108.471 101.013 101.474 100.744 101.421 100.692C101.386 100.657 103.239 96.8284 105.529 92.1781L109.694 83.7225L110.463 83.8508L110.469 83.8391ZM105.622 102.277C108.372 102.353 111.15 102.469 111.785 102.539L112.945 102.667L106.711 120.033L105.197 120.057C103.886 120.074 92.1235 119.625 91.9837 119.55C91.9545 119.532 93.8886 115.61 96.2714 110.832L100.612 102.137L105.616 102.271L105.622 102.277ZM94.5761 110.779C92.1992 115.534 90.2242 119.462 90.1834 119.509C90.1426 119.555 87.6026 119.713 84.5383 119.858C78.3513 120.156 77.4366 120.185 77.4366 120.057C77.4366 119.911 87.6726 103.297 87.9231 103.035C88.0746 102.871 89.496 102.714 91.9428 102.58C94.0226 102.464 96.4403 102.318 97.3142 102.254L98.9046 102.131L94.5819 110.779H94.5761ZM82.7322 121.391C86.2277 121.239 89.1407 121.164 89.2047 121.222C89.2688 121.286 87.3404 125.325 84.9285 130.208L80.5359 139.077L76.3763 139.211C74.0926 139.287 70.6728 139.409 68.7794 139.479L65.3423 139.613L66.7229 137.387C67.4803 136.164 69.962 132.125 72.2399 128.413L76.3763 121.671L82.7322 121.391ZM81.5379 140.587L82.703 140.686C83.3439 140.744 87.2648 140.93 91.4244 141.105C95.5782 141.28 98.9921 141.437 99.0038 141.461C99.0271 141.496 94.0634 155.318 92.7934 158.762C92.3623 159.928 92.1293 160.301 91.8263 160.324C91.3137 160.359 72.4438 159.351 72.3739 159.287C72.3448 159.258 74.3955 155.039 76.9297 149.91L81.5379 140.587ZM91.4417 162.125C91.4825 162.241 89.9738 166.653 88.0804 171.932C86.187 177.206 84.5557 181.542 84.4566 181.565C84.1595 181.623 65.2315 180.464 63.5246 180.283L61.9808 180.12L71.3836 161.017H72.2109C74.9199 160.988 91.3777 161.95 91.4476 162.136L91.4417 162.125ZM64.0548 183.82C66.187 185.126 68.0629 186.32 68.2318 186.478C68.4882 186.722 67.3695 186.757 60.5708 186.746L52.6128 186.728L41.4157 181.751L46.8104 181.623C49.7757 181.553 53.9993 181.483 56.1957 181.472L60.1864 181.443L64.0605 183.814L64.0548 183.82ZM52.6537 187.765L58.328 190.265C61.4506 191.641 63.9207 192.794 63.8217 192.824C63.7226 192.853 61.5613 193.062 59.0154 193.296C56.4753 193.523 54.3605 193.704 54.3139 193.692C53.7547 193.564 40.8331 189.053 40.7283 188.948C40.6467 188.867 40.8039 188.803 41.0777 188.803C41.3515 188.803 44.0606 188.57 47.1075 188.284L52.6478 187.765H52.6537ZM54.6344 194.717L61.4332 197.019C65.1733 198.284 68.2318 199.374 68.2318 199.444C68.2318 199.508 67.2822 199.764 66.117 200.003C64.9519 200.248 63.7809 200.44 63.5129 200.428C63.1517 200.417 49.432 196.734 48.162 196.308C48.0513 196.273 49.4669 195.9 51.302 195.481L54.6402 194.717H54.6344ZM65.0626 201.827C66.6706 202.212 79.7727 205.795 79.8485 205.865C79.8892 205.906 79.6446 206.081 79.3009 206.262C78.9572 206.436 78.4677 206.576 78.2114 206.565C77.8677 206.553 64.6431 203.703 61.9108 203.057C61.7418 203.016 62.1963 202.678 62.9245 202.305C64.1071 201.699 64.3286 201.646 65.0685 201.827H65.0626ZM68.9659 205.452C73.4518 206.419 77.2502 207.252 77.4016 207.305C77.6289 207.386 77.6113 207.485 77.32 207.806C77.1161 208.027 76.7608 208.202 76.5278 208.19C76.2948 208.179 73.0207 207.637 69.2572 206.99C65.4937 206.343 61.7419 205.696 60.9263 205.562L59.4348 205.312L59.9476 204.461C60.2272 203.995 60.5359 203.633 60.635 203.651C60.734 203.674 64.4859 204.478 68.9717 205.446L68.9659 205.452ZM76.8657 209.309C76.9473 209.438 77.0172 209.659 77.0172 209.799C77.0172 210.038 76.1783 210.108 75.3859 209.939C75.217 209.904 71.8148 209.49 67.8299 209.03C63.8392 208.563 60.4485 208.121 60.297 208.039C60.0057 207.887 59.3359 206.425 59.4931 206.267C59.6679 206.093 76.7201 209.076 76.8657 209.309ZM61.6953 209.117C62.0915 209.181 65.8607 209.653 70.0728 210.16C77.355 211.034 77.757 211.11 78.2405 211.588L78.7474 212.095L77.221 212.066C74.2499 212.013 63.4314 211.139 63.0294 210.918C62.8022 210.795 62.2546 210.312 61.806 209.845L60.9904 208.995L61.707 209.111L61.6953 209.117ZM72.4206 212.631C79.5339 213.115 79.8077 213.15 80.8447 213.686C81.4331 213.989 81.9166 214.309 81.9166 214.391C81.9166 214.472 81.8933 214.525 81.8642 214.496C81.835 214.472 78.8231 214.402 75.1762 214.344L68.5348 214.239L66.7637 213.22C65.785 212.66 65.0044 212.182 65.0277 212.165C65.051 212.141 68.3775 212.351 72.4206 212.631ZM77.3492 215.288C83.7517 215.393 83.8857 215.405 85.1907 215.923C85.9189 216.215 86.5889 216.512 86.6763 216.588C86.7637 216.664 84.5092 216.879 81.672 217.071C78.8348 217.264 76.3705 217.415 76.2015 217.409C75.9044 217.398 71.1097 215.451 70.9291 215.271C70.8767 215.218 73.7721 215.23 77.3492 215.288ZM79.7786 218.167C80.4544 218.097 82.8488 217.928 85.0975 217.794L89.1872 217.549L91.2263 218.225C92.3448 218.598 93.172 218.93 93.0555 218.965C92.9448 218.995 91.2437 219.303 89.2746 219.653C87.3054 219.997 85.517 220.317 85.2898 220.358C85.0626 220.399 83.4546 219.95 81.7127 219.362L78.5435 218.289L79.767 218.161L79.7786 218.167ZM91.7797 220.265L95.4091 219.618L97.9084 220.282C99.2833 220.65 100.437 220.97 100.466 220.993C100.501 221.022 99.3474 221.512 97.9143 222.089C96.4753 222.666 95.1645 223.126 94.9955 223.12C94.2382 223.08 87.5735 221.127 87.8473 221.028C88.0162 220.97 89.7873 220.626 91.7797 220.271V220.265ZM99.9825 222.549L102.581 221.477L105.47 222.106C107.061 222.45 108.389 222.765 108.424 222.8C108.459 222.835 107.917 223.47 107.206 224.204L105.925 225.544L101.94 224.676C99.7493 224.198 97.8269 223.761 97.6696 223.709C97.5123 223.656 98.5493 223.132 99.9825 222.543V222.549ZM109.251 224.408L110.422 223.126L113.469 223.651C115.147 223.942 116.586 224.216 116.662 224.262C116.743 224.309 116.866 224.88 116.941 225.527C117.017 226.174 117.128 226.867 117.18 227.065C117.256 227.316 117.18 227.415 116.912 227.403C115.992 227.345 108.063 225.923 108.069 225.813C108.069 225.749 108.599 225.113 109.245 224.408H109.251ZM116.854 213.109C116.854 212.946 116.796 212.479 116.726 212.072L116.603 211.331L117.454 211.483C117.92 211.57 118.345 211.681 118.392 211.728C118.444 211.78 118.118 212.176 117.67 212.613C117.186 213.091 116.854 213.289 116.854 213.115V213.109ZM117.338 210.638L116.487 210.446L116.236 208.703C116.102 207.748 116.044 206.908 116.108 206.844C116.237 206.716 121.957 207.596 121.957 207.748C121.957 207.794 121.34 208.517 120.582 209.356C119.108 210.982 119.021 211.017 117.332 210.638H117.338ZM115.922 205.714C115.776 205.568 115.205 202.031 115.31 201.932C115.398 201.844 124.095 203.225 125.109 203.482L125.703 203.633L124.2 205.312C123.373 206.232 122.604 206.978 122.487 206.961C121.41 206.827 116.009 205.795 115.922 205.714ZM126.304 205.288L127.585 203.896L132.438 204.968C135.106 205.556 137.221 206.104 137.134 206.18C137.046 206.256 135.7 206.838 134.139 207.474C132.572 208.115 131.022 208.622 130.667 208.604C130.317 208.593 128.814 208.301 127.329 207.963C124.229 207.252 124.305 207.456 126.298 205.294L126.304 205.288ZM136.382 207.841L139.563 206.576L143.758 207.748C146.676 208.563 147.836 208.966 147.573 209.07C147.364 209.158 145.348 209.548 143.087 209.945C140.833 210.341 138.718 210.661 138.386 210.65C137.67 210.626 133.195 209.403 133.195 209.228C133.195 209.158 134.628 208.534 136.376 207.841H136.382ZM138.625 211.891C138.969 211.891 139.977 212.159 140.874 212.485L142.493 213.074L141.165 213.202C140.437 213.272 137.728 213.464 135.153 213.633C132.572 213.802 130.416 213.925 130.352 213.913C129.799 213.796 129.525 213.68 129.525 213.563C129.525 213.394 137.734 211.885 138.625 211.891ZM130.778 220.888C131.255 220.888 142.522 224.624 142.767 224.874C142.82 224.927 141.992 224.973 140.932 224.973C139.872 224.973 138.911 224.886 138.806 224.781C138.701 224.676 136.726 223.761 134.425 222.742C131.896 221.629 130.451 220.894 130.778 220.888ZM143.927 225.83C146.14 225.912 146.251 225.935 151.424 227.73C154.314 228.732 156.644 229.583 156.609 229.618C156.569 229.659 155.252 229.752 153.679 229.833L150.813 229.979L146.414 228.039C143.997 226.966 141.94 226.017 141.847 225.923C141.753 225.83 142.692 225.789 143.927 225.836V225.83ZM147.591 225.422C147.62 225.393 148.22 225.271 148.913 225.16C150.148 224.962 150.329 224.997 157.11 226.838C160.926 227.87 164.014 228.744 163.979 228.779C163.944 228.814 162.983 228.983 161.835 229.152C160.687 229.327 159.592 229.461 159.394 229.449C158.992 229.431 147.498 225.51 147.585 225.422H147.591ZM159.138 226.512C155.601 225.55 152.525 224.688 152.304 224.595C151.96 224.449 152.03 224.379 152.799 224.123C153.65 223.837 153.871 223.86 157.291 224.606C159.266 225.038 162.633 225.754 164.765 226.209C166.898 226.663 168.832 227.106 169.053 227.2C169.374 227.328 169.117 227.479 167.824 227.905C166.181 228.452 165.831 228.522 165.662 228.353C165.61 228.301 162.68 227.473 159.143 226.512H159.138ZM162.814 224.973C158.602 224.064 155.025 223.272 154.867 223.219C154.634 223.138 154.658 223.039 154.99 222.707L155.403 222.293L163.455 223.639C167.882 224.379 171.78 225.038 172.117 225.107L172.729 225.236L171.838 226.028C170.97 226.797 170.754 226.914 170.568 226.727C170.521 226.681 167.032 225.888 162.819 224.979L162.814 224.973ZM155.928 221.506C155.928 221.506 155.875 221.256 155.875 220.97C155.875 220.475 155.922 220.451 156.644 220.562C157.78 220.743 172.747 222.52 173.12 222.52C173.37 222.52 173.446 222.736 173.446 223.429C173.446 223.93 173.376 224.367 173.294 224.408C173.189 224.461 159.196 222.124 155.928 221.506ZM172.409 218.843L170.836 217.794C169.968 217.217 169.17 216.658 169.059 216.559C168.937 216.448 171.949 216.395 176.615 216.43L184.375 216.489L186.775 218.19C188.098 219.129 189.176 219.933 189.176 219.979C189.176 220.026 189.012 220.055 188.82 220.038C188.622 220.02 184.853 219.746 180.437 219.426L172.409 218.837V218.843ZM177.122 219.974C179.091 220.119 181.613 220.294 182.738 220.37C183.862 220.446 185.837 220.591 187.131 220.69C188.424 220.795 189.688 220.877 189.939 220.883C190.265 220.883 190.673 221.256 191.337 222.159C191.85 222.858 192.362 223.592 192.467 223.796C192.572 223.994 192.589 224.146 192.502 224.14C192.415 224.128 188.436 223.633 183.658 223.033C178.881 222.439 174.972 221.937 174.966 221.932C174.966 221.92 174.605 221.448 174.174 220.888C173.743 220.323 173.423 219.828 173.469 219.787C173.516 219.746 175.159 219.834 177.122 219.979V219.974ZM191.628 220.108C191.174 219.95 187.136 217.246 186.624 216.751C186.495 216.623 189.245 216.582 194.29 216.634L202.161 216.71L205.121 218.826C206.746 219.985 208.168 221.017 208.272 221.122C208.389 221.226 208.004 221.291 207.352 221.279C204.893 221.221 192.112 220.277 191.634 220.113L191.628 220.108ZM199.895 214.426C198.101 213.569 195.735 212.45 194.64 211.937C193.545 211.425 192.7 210.953 192.764 210.889C192.828 210.824 195.933 210.574 199.656 210.341L206.431 209.91L218.479 215.958L203.146 215.982L199.883 214.426H199.895ZM213.393 211.972L207.072 208.837L204.154 197.963C202.552 191.984 201.27 187.06 201.305 187.019C201.456 186.868 212.479 192.742 212.648 193.062C212.747 193.249 213.667 196.023 214.704 199.222C215.741 202.427 217.308 207.293 218.2 210.044C219.085 212.788 219.79 215.055 219.767 215.073C219.743 215.09 216.877 213.697 213.399 211.972H213.393ZM202.645 197.264C204.229 203.208 205.499 208.097 205.47 208.126C205.412 208.179 188.348 201.938 188.232 201.815C188.092 201.675 184.241 180.615 184.317 180.405C184.387 180.219 199.173 185.866 199.528 186.209C199.656 186.338 201.06 191.308 202.645 197.252V197.264ZM199.044 184.298C198.881 184.286 184.014 178.605 183.926 178.517C183.787 178.377 180.122 157.935 180.221 157.842C180.309 157.754 193.067 162.702 193.417 162.958C193.446 162.981 194.71 167.62 196.219 173.261C197.728 178.902 199.021 183.698 199.085 183.913C199.155 184.129 199.132 184.304 199.044 184.298ZM192.892 161.204C192.752 161.192 179.942 156.087 179.819 155.994C179.714 155.913 176.091 136.024 176.166 135.948C176.248 135.866 187.16 140.342 187.375 140.546C187.451 140.616 188.628 144.864 189.997 149.975C191.36 155.091 192.601 159.706 192.758 160.242C192.916 160.779 192.974 161.21 192.898 161.204H192.892ZM181.194 136.449L175.765 134.188L173.999 124.567C173.026 119.276 172.275 114.911 172.321 114.858C172.473 114.707 181.509 118.67 181.66 118.949C181.8 119.212 186.927 138.349 186.927 138.611C186.927 138.832 186.711 138.751 181.188 136.449H181.194ZM176.475 115.074L171.849 113.087L171.721 112.271C171.652 111.822 170.894 107.656 170.043 103.017C169.193 98.3785 168.541 94.5266 168.605 94.4683C168.663 94.4101 170.352 95.086 172.35 95.9718L175.986 97.586L177.78 104.317C178.771 108.017 179.936 112.405 180.373 114.06C180.809 115.715 181.153 117.073 181.136 117.067C181.118 117.067 179.021 116.164 176.475 115.074ZM175.339 95.8203C175.252 95.8203 173.574 95.0977 171.605 94.2236C168.232 92.7201 168.028 92.5977 167.97 92.0324C167.935 91.7061 167.218 87.6735 166.379 83.0757C165.54 78.4779 164.893 74.6784 164.946 74.6259C164.998 74.5735 166.263 75.0864 167.76 75.7682L170.48 77.0036L172.852 85.8787C174.157 90.7621 175.287 94.9928 175.363 95.29C175.438 95.5814 175.427 95.8203 175.339 95.8203ZM167.066 74.0899C164.299 72.8486 164.264 72.8253 164.259 72.1668C164.259 71.7997 163.6 67.9128 162.802 63.5247C162.004 59.1367 161.392 55.5062 161.439 55.4537C161.491 55.4013 162.348 55.7393 163.35 56.1996L165.173 57.033L167.591 66.1238C168.919 71.1237 169.974 75.2436 169.939 75.2786C169.904 75.3136 168.61 74.7775 167.066 74.084V74.0899ZM161.474 64.0433C162.295 68.4955 162.907 72.1668 162.843 72.2076C162.779 72.2483 161.223 71.7588 159.388 71.1237C156.213 70.0281 156.062 69.9524 156.149 69.4804C156.202 69.2065 155.986 65.4361 155.671 61.1005C155.357 56.7649 155.135 53.181 155.176 53.1402C155.217 53.0995 156.283 53.42 157.553 53.857C159.808 54.6262 159.86 54.6612 159.924 55.3022C159.959 55.6577 160.658 59.597 161.474 64.0433ZM155.293 78.5594C155.59 82.7144 155.875 86.6887 155.933 87.3938C156.003 88.2738 155.963 88.6642 155.799 88.6526C154.838 88.571 145.895 86.1293 145.989 85.9719C146.094 85.8029 147.061 71.45 147.078 69.8183C147.078 69.4221 147.189 69.2589 147.439 69.2647C147.637 69.2647 149.362 69.661 151.267 70.1389L154.739 71.0071L155.281 78.5653L155.293 78.5594ZM146.327 49.4165C146.018 49.399 141.136 48.4958 141.025 48.4375C141.002 48.4259 141.153 48.0238 141.357 47.5518C141.561 47.0739 142.359 43.6241 143.134 39.8887C144.381 33.8515 144.585 33.0939 144.928 33.0939C145.144 33.0939 145.89 33.1988 146.595 33.3328C147.783 33.5543 147.865 33.6009 147.696 33.9972C147.538 34.3643 146.688 46.8233 146.688 48.758C146.688 49.2825 146.606 49.4398 146.333 49.4224L146.327 49.4165ZM142.802 33.3153C142.686 33.5834 141.917 37.0216 141.101 40.9551L139.621 48.1053L138.607 48.1345C137.553 48.1637 134.209 47.8548 134.069 47.715C134.022 47.6683 134.209 47.2779 134.483 46.8467C134.757 46.4154 136.062 43.0064 137.39 39.271L139.802 32.4821L141.357 32.6102C142.208 32.6802 142.936 32.756 142.965 32.7851C143 32.8084 142.924 33.0531 142.808 33.3212L142.802 33.3153ZM139.243 49.6962C139.295 49.7487 136.114 65.1214 135.962 65.5294C135.852 65.8324 135.893 65.8324 131.564 65.3662C129.711 65.168 128.109 64.9933 128.01 64.9874C127.911 64.9758 127.97 64.8068 128.139 64.6086C128.313 64.4105 129.63 60.9432 131.063 56.8931C132.502 52.8489 133.749 49.4515 133.842 49.3466C133.982 49.1893 139.062 49.5097 139.243 49.6962ZM132.071 49.3874C131.989 49.5856 130.783 52.9188 129.391 56.7941C127.999 60.6693 126.758 64.0958 126.636 64.4047C126.414 64.9583 126.385 64.9641 124.748 64.9291C120.582 64.83 118.823 64.6669 119.126 64.4163C119.289 64.2823 121.113 60.7626 123.187 56.6018L126.95 49.032H129.583C132.013 49.032 132.205 49.0611 132.065 49.3874H132.071ZM117.553 64.7427C117.512 64.7893 116.487 64.9 115.275 64.9932C114.063 65.0864 112.601 65.203 112.024 65.2496L110.97 65.3429L111.541 64.4921C111.85 64.0259 114.058 60.4653 116.44 56.5901C118.823 52.7149 120.792 49.5214 120.81 49.5039C120.868 49.4457 125.127 49.0727 125.179 49.1193C125.231 49.1659 117.705 64.5853 117.553 64.7427ZM112.403 66.5258C113.556 66.4501 115.042 66.3335 115.694 66.2636L116.883 66.1354L108.715 82.4755L107.014 82.6037C103.455 82.8718 100.309 83.0058 100.309 82.8893C100.309 82.761 109.304 68.0876 109.933 67.196C110.283 66.7007 110.451 66.654 112.409 66.5258H112.403ZM103.46 84.2004C105.779 84.0431 107.725 83.9673 107.783 84.0256C107.865 84.1072 99.8659 100.383 99.6037 100.675C99.5804 100.704 97.221 100.861 94.3663 101.03C91.5117 101.199 89.1057 101.339 89.0183 101.339C88.9367 101.339 89.3679 100.535 89.9738 99.5498C90.5855 98.565 92.9158 94.7714 95.1587 91.1176L99.2367 84.4743L103.455 84.1946L103.46 84.2004ZM87.358 101.275C87.1075 101.537 78.8581 102.988 78.8581 102.767C78.8581 102.691 80.664 100.063 82.872 96.9275C85.08 93.7923 87.7016 90.057 88.7037 88.6292C89.7057 87.2015 90.6786 85.9894 90.8708 85.9312C91.6748 85.6922 97.3026 84.7715 97.39 84.8648C97.489 84.9638 87.7949 100.809 87.358 101.269V101.275ZM86.1812 103.081C86.2627 103.157 76.0791 119.719 75.7296 120.08C75.6014 120.214 73.3528 120.651 70.737 121.053C68.1212 121.449 65.8317 121.776 65.6569 121.776C65.4006 121.776 65.4354 121.642 65.8316 121.111C66.1054 120.744 68.8436 116.875 71.9138 112.51C74.984 108.145 77.5939 104.538 77.7163 104.491C78.1124 104.346 86.1113 103.011 86.1812 103.081ZM74.3606 122.015C74.4771 122.055 73.5742 123.693 72.3566 125.663C71.1331 127.632 68.6863 131.583 66.9152 134.45C65.1442 137.317 63.6818 139.672 63.6644 139.689C63.6469 139.701 61.1069 140.056 58.0192 140.47C54.9315 140.884 52.2225 141.274 52.0011 141.338C51.6108 141.449 51.6108 141.443 51.9894 140.866C52.4905 140.097 63.9673 123.769 64.1305 123.594C64.2819 123.425 74.0693 121.927 74.3664 122.026L74.3606 122.015ZM64.3693 141.228L66.251 141.111C68.5405 140.971 79.5456 140.621 79.633 140.686C79.7728 140.796 70.4514 159.193 70.2184 159.263C70.0786 159.304 66.1637 159.403 61.5089 159.473L53.0498 159.601L53.3586 159.129C53.5275 158.867 56.0734 154.735 59.0154 149.94L64.3634 141.222L64.3693 141.228ZM56.3996 161.181C63.7052 160.953 69.461 160.901 69.461 161.064C69.461 161.146 67.323 165.493 64.713 170.72L59.9651 180.225H52.3857C48.2144 180.225 43.8101 180.283 42.5925 180.359C40.536 180.487 40.3903 180.469 40.5185 180.137C40.5942 179.939 42.1381 177.369 43.9558 174.432C45.7676 171.495 48.3251 167.34 49.6359 165.207L52.0186 161.326L56.3996 161.186V161.181ZM44.1829 184.03C49.4145 186.332 50.7136 186.938 50.4165 186.955C50.3349 186.955 47.8066 187.194 44.8005 187.474C41.7944 187.754 39.0561 188.028 38.7183 188.074C38.2988 188.132 36.0269 187.451 31.5701 185.924C27.9756 184.694 24.8005 183.581 24.5208 183.453C24.0956 183.255 25.2665 183.086 31.436 182.451L38.8639 181.687L44.1888 184.024L44.1829 184.03ZM44.6665 191.314C51.7274 193.727 52.7003 194.076 52.4032 194.1C52.2925 194.106 50.8302 194.438 49.1582 194.828C47.4862 195.219 45.8782 195.533 45.5811 195.527C44.7072 195.498 29.7 191.308 30.032 191.18C30.201 191.116 32.1409 190.632 34.3489 190.108L38.3571 189.152L44.6665 191.308V191.314ZM46.3384 196.699L54.0693 198.802C58.3221 199.962 61.8817 200.953 61.9866 201.017C62.0915 201.075 61.5845 201.431 60.8621 201.804C60.1456 202.177 59.4175 202.474 59.2485 202.468C58.6718 202.45 42.7265 198.919 42.5867 198.779C42.5109 198.698 43.3208 198.202 44.3927 197.666L46.3384 196.699ZM50.1544 201.378C54.6461 202.351 58.3979 203.191 58.4795 203.237C58.561 203.29 58.427 203.692 58.1707 204.135C57.8211 204.752 57.594 204.933 57.2036 204.921C56.4638 204.892 40.2214 202.13 40.1049 202.008C40.0524 201.955 40.3146 201.355 40.6874 200.673C41.1419 199.846 41.4681 199.461 41.6778 199.519C41.8468 199.566 45.6627 200.399 50.1544 201.378ZM57.3318 205.848C57.46 205.894 57.7046 206.355 57.8794 206.868L58.1998 207.806L57.5473 207.783C56.8365 207.753 42.7672 206.052 41.7768 205.871C41.2466 205.772 41.0895 205.58 40.6059 204.397C40.2972 203.645 40.0757 203.004 40.1049 202.975C40.1689 202.911 56.9648 205.72 57.326 205.854L57.3318 205.848ZM58.4328 208.82C58.8348 208.931 59.5514 209.426 60.0582 209.945L60.9671 210.871L59.6505 210.848C58.9222 210.836 55.5141 210.621 52.0653 210.376L45.7967 209.927L44.0373 208.435C43.0702 207.614 42.3071 206.908 42.3479 206.873C42.4585 206.763 57.6405 208.61 58.4328 208.826V208.82ZM55.0538 211.425L62.3944 211.949L64.2878 212.998C65.3306 213.575 66.1812 214.117 66.187 214.21C66.187 214.303 65.5927 214.35 64.8645 214.309C64.1363 214.274 61.1709 214.199 58.2755 214.146L53.0148 214.041L50.3117 212.52C48.8261 211.687 47.6318 210.982 47.6609 210.953C47.69 210.924 51.0165 211.139 55.0538 211.425ZM61.8585 215.113L68.1329 215.183L70.9408 216.337C72.4846 216.972 73.7255 217.514 73.6906 217.543C73.6614 217.573 71.4652 217.742 68.8144 217.916C66.1637 218.091 63.775 218.231 63.5071 218.225C63.1109 218.225 55.9161 215.381 55.6656 215.125C55.619 215.078 58.4096 215.079 61.8585 215.113ZM71.2204 218.721L75.9744 218.394L79.5105 219.571C81.4563 220.218 82.9537 220.778 82.843 220.807C82.7323 220.836 81.1126 221.145 79.2542 221.489C77.39 221.832 75.5957 222.106 75.2695 222.101C74.5645 222.089 65.4996 219.099 66.0763 219.064C66.2919 219.053 68.6105 218.895 71.2204 218.715V218.721ZM81.4914 222.13L85.3305 221.442L89.4494 222.52C91.7156 223.114 93.5683 223.656 93.5683 223.721C93.5683 223.785 92.4438 224.28 91.0631 224.816C89.6882 225.352 88.4707 225.778 88.3542 225.76C87.958 225.702 77.7862 222.94 77.7221 222.87C77.6871 222.835 79.3824 222.497 81.4914 222.118V222.13ZM96.0909 224.309C96.4928 224.338 105.278 226.209 105.354 226.279C105.377 226.302 104.888 226.891 104.264 227.584C103.641 228.283 102.983 228.843 102.79 228.837C101.899 228.79 90.9116 226.32 91.0515 226.197C91.3894 225.9 95.7122 224.28 96.085 224.309H96.0909ZM106.181 227.864L107.358 226.605L112.158 227.421C114.797 227.87 117.058 228.278 117.186 228.324C117.308 228.371 117.501 229.064 117.606 229.857L117.803 231.308L117.18 231.29C116.394 231.267 105.237 229.356 105.103 229.222C105.051 229.169 105.535 228.557 106.181 227.864ZM117.71 218.336L117.774 217.794L119.394 219.449H118.631C117.803 219.449 117.606 219.21 117.71 218.33V218.336ZM119.033 213.552L119.551 212.876C120.122 212.136 120.489 211.996 121.311 212.2C121.742 212.31 121.788 212.375 121.544 212.509C121.375 212.602 120.74 212.876 120.134 213.115L119.033 213.546V213.552ZM121.043 218.843C121.491 219.111 122.039 219.449 122.26 219.595C122.645 219.851 122.639 219.863 122.144 219.863C121.59 219.863 121.27 219.647 120.623 218.855L120.221 218.359L121.037 218.843H121.043ZM122.476 213.639C122.249 213.686 122.435 213.546 122.884 213.324C123.758 212.893 124.527 212.8 124.707 213.091C124.771 213.19 124.387 213.336 123.851 213.412C123.32 213.488 122.697 213.587 122.476 213.639ZM122.983 211.658C122.039 211.646 121.247 211.413 121.247 211.157C121.247 211.04 121.847 210.288 122.575 209.484L123.903 208.021L126.659 208.633C128.174 208.971 129.461 209.245 129.519 209.251C129.578 209.257 128.29 209.805 126.665 210.469C124.917 211.18 123.408 211.669 122.988 211.664L122.983 211.658ZM128.646 210.976L131.651 209.781L133.498 210.259C136.79 211.104 136.831 211.052 132.182 211.914C129.88 212.345 127.673 212.683 127.276 212.678C126.298 212.654 125.639 212.514 125.639 212.328C125.639 212.246 126.991 211.634 128.646 210.976ZM127.183 220.929C127.719 220.877 129.904 221.768 136.37 224.682C136.935 224.933 136.807 224.956 134.815 224.968C133.207 224.973 132.584 224.904 132.409 224.694C132.281 224.536 130.917 223.639 129.379 222.701C126.909 221.191 126.653 220.982 127.189 220.929H127.183ZM139.359 225.993L143.583 227.852C145.907 228.878 147.841 229.752 147.894 229.793C147.94 229.839 146.373 229.874 144.41 229.874C142.138 229.874 140.763 229.793 140.623 229.653C140.501 229.53 139.132 228.656 137.576 227.712L134.751 225.993H139.365H139.359ZM146.624 230.853L150.667 230.964L159.242 234.775L157.198 234.734C156.073 234.711 153.702 234.67 151.919 234.635L148.686 234.571L145.686 232.712C144.037 231.692 142.662 230.83 142.627 230.801C142.592 230.772 144.387 230.801 146.612 230.853H146.624ZM157.361 232.905C155.089 231.885 153.271 230.982 153.318 230.9C153.364 230.818 154.78 230.696 156.452 230.626L159.499 230.492L170.673 234.315L169.245 234.437C168.465 234.507 166.396 234.606 164.655 234.659L161.485 234.758L157.355 232.899L157.361 232.905ZM161.946 230.306C161.858 230.218 162.913 229.991 164.294 229.793L166.805 229.437L173.242 231.191C176.778 232.153 179.813 233.004 179.982 233.074C180.151 233.143 178.91 233.412 177.227 233.668C175.543 233.924 173.842 234.128 173.446 234.128C172.77 234.128 162.289 230.638 161.946 230.3V230.306ZM168.581 229.041C168.436 228.989 169.1 228.68 170.067 228.353L171.82 227.759L179.225 229.338C183.297 230.206 186.857 230.993 187.137 231.081C187.562 231.215 187.259 231.366 185.237 231.995C183.915 232.409 182.715 232.782 182.581 232.817C182.388 232.87 169.834 229.478 168.581 229.035V229.041ZM182.027 229.152C178.264 228.318 174.698 227.538 174.11 227.415C173.521 227.293 173.038 227.13 173.038 227.054C173.038 226.978 173.417 226.605 173.877 226.221L174.71 225.527L183.117 226.914C187.742 227.677 191.599 228.371 191.698 228.452C191.791 228.534 191.249 229.076 190.492 229.647C189.735 230.218 189.059 230.684 188.989 230.678C188.925 230.673 185.785 229.985 182.021 229.152H182.027ZM175.147 224.7C175.1 224.653 175.124 224.239 175.199 223.773C175.316 223.05 175.409 222.928 175.835 222.928C176.341 222.928 191.18 224.676 192.403 224.88C193.131 225.003 193.12 224.927 192.723 227.065C192.636 227.52 192.514 227.625 192.071 227.607C191.389 227.584 175.258 224.81 175.147 224.7ZM192.519 221.151C192.613 221.057 205.843 221.943 208.628 222.235L209.793 222.357L211.028 224.262C211.71 225.311 212.263 226.22 212.263 226.285C212.263 226.477 211.535 226.401 203.07 225.364C198.631 224.816 194.937 224.367 194.856 224.367C194.64 224.356 192.397 221.273 192.519 221.151ZM210.818 221.512L207.655 219.233C205.919 217.981 204.492 216.902 204.492 216.844C204.492 216.786 208.092 216.798 212.496 216.873L220.501 217.013L224.089 219.694C226.064 221.168 227.766 222.456 227.87 222.555C228.103 222.771 228.867 222.806 218.939 222.101L210.812 221.524L210.818 221.512ZM221.316 215.83C221.072 215.463 214.057 194.094 214.151 194.001C214.18 193.972 215.712 195.16 217.565 196.641L220.926 199.333L224.148 208.424C225.919 213.423 227.69 218.412 228.08 219.507C228.47 220.603 228.773 221.5 228.75 221.494C228.558 221.483 221.503 216.104 221.316 215.83ZM219.86 196.757C219.726 196.745 213.929 192.188 213.498 191.757C213.312 191.571 206.298 170.365 206.397 170.283C206.461 170.231 211.278 174.246 211.89 174.858C212.315 175.283 213.207 177.556 215.741 184.706C217.559 189.822 219.254 194.624 219.516 195.382C219.779 196.139 219.93 196.757 219.854 196.745L219.86 196.757ZM208.395 179.828C210.3 185.708 211.832 190.574 211.803 190.65C211.774 190.726 209.251 189.49 206.204 187.899L200.658 185.015L200.116 182.969C199.819 181.845 198.555 177.13 197.314 172.486C196.067 167.847 195.094 164.001 195.153 163.949C195.223 163.879 204.317 168.686 204.87 169.088C204.905 169.118 206.495 173.943 208.395 179.823V179.828ZM194.529 161.932C194.419 161.828 188.995 141.501 189.059 141.437C189.094 141.402 190.999 142.434 193.289 143.728L197.454 146.082L200.192 154.514C201.701 159.153 203.227 163.89 203.594 165.044C203.961 166.198 204.2 167.136 204.124 167.13C204.002 167.125 194.681 162.072 194.535 161.932H194.529ZM196.597 144.048C196.504 144.048 194.64 143.028 192.449 141.781L188.465 139.52L185.843 129.713C184.404 124.316 183.268 119.858 183.326 119.8C183.425 119.701 190.201 123.576 190.201 123.728C190.201 123.769 191.616 128.151 193.341 133.465C195.071 138.78 196.545 143.337 196.621 143.588C196.697 143.838 196.685 144.048 196.597 144.042V144.048ZM182.47 117.341C182.435 117.137 181.299 112.848 179.953 107.807C178.607 102.767 177.536 98.6117 177.582 98.565C177.705 98.4427 183.076 101.782 183.157 102.032C183.198 102.161 184.626 106.56 186.321 111.817C188.022 117.073 189.379 121.449 189.344 121.537C189.228 121.816 182.54 117.731 182.47 117.341ZM177.052 96.6653C176.866 96.5138 176.714 96.234 176.714 96.0534C176.714 95.8727 175.654 91.7819 174.366 86.9685C173.073 82.155 172.018 78.134 172.018 78.0408C172.018 77.9476 172.986 78.4662 174.162 79.2063C175.345 79.9464 176.306 80.6515 176.306 80.7797C176.306 80.9079 177.681 85.2377 179.359 90.4066C181.037 95.5756 182.389 99.8237 182.365 99.847C182.301 99.9111 177.483 97.0266 177.052 96.6653ZM173.341 77.3474C171.803 76.38 171.284 75.9429 171.232 75.5758C171.197 75.3078 170.154 71.3277 168.925 66.7357C167.696 62.1437 166.711 58.3092 166.746 58.2101C166.828 57.9712 169.566 59.6903 169.566 59.9816C169.566 60.1972 170.306 62.5224 174.081 74.1423C174.861 76.5432 175.473 78.5361 175.444 78.5711C175.415 78.6003 174.465 78.0525 173.347 77.3474H173.341ZM167.165 56.9456C166.082 56.2346 165.872 56.0015 165.773 55.378C165.709 54.9759 164.707 51.0599 163.542 46.6777C162.377 42.2954 161.462 38.6707 161.503 38.63C161.643 38.4901 163.023 39.6381 163.023 39.8887C163.023 40.0752 168.296 56.5085 168.692 57.5632C168.843 57.9712 168.523 57.843 167.165 56.9514V56.9456ZM162.412 46.8816C163.647 51.4911 164.661 55.2847 164.661 55.3139C164.661 55.4479 164.218 55.2789 162.569 54.5038C160.95 53.7463 160.78 53.6181 160.78 53.0995C160.78 52.7848 160.14 49.0086 159.359 44.708C158.578 40.4073 157.972 36.8526 158.013 36.8118C158.054 36.771 158.555 36.9808 159.126 37.2664C159.773 37.5927 160.169 37.9307 160.169 38.1463C160.169 38.3386 161.182 42.2721 162.418 46.8816H162.412ZM159.307 52.8081C159.248 53.047 158.048 52.7207 155.508 51.7708C154.926 51.5533 154.675 51.1609 154.757 50.5937C154.827 50.1275 154.64 46.4912 154.349 42.5169C154.057 38.5426 153.848 35.2559 153.883 35.2209C153.918 35.186 154.547 35.3724 155.269 35.6346C156.207 35.9785 156.574 36.2116 156.533 36.4388C156.498 36.6137 157.128 40.3141 157.92 44.6614C158.718 49.0086 159.342 52.6741 159.307 52.8139V52.8081ZM154.564 68.0818C154.716 69.7426 155.001 69.7018 150.97 68.6587C149.339 68.2391 147.754 67.8312 147.439 67.7555C146.968 67.6389 146.909 67.5515 147.072 67.2368C147.183 67.027 147.474 63.4198 147.719 59.2183C147.964 55.0167 148.232 51.5086 148.308 51.4154C148.383 51.3279 149.589 51.5377 150.987 51.8932L153.527 52.5284L153.568 53.857C153.609 55.2206 154.331 65.6284 154.553 68.0818H154.564ZM153.067 51.0541C152.793 51.0191 148.558 49.906 148.232 49.7778C147.969 49.6787 147.952 49.5564 148.139 49.0844C148.267 48.7697 148.57 45.2733 148.826 41.3048C149.076 37.3363 149.321 34.0555 149.368 34.0088C149.414 33.9622 150.096 34.0846 150.877 34.2885C152.053 34.5916 152.292 34.7198 152.257 35.0461C152.234 35.2618 152.438 38.5425 152.718 42.3362C152.997 46.1298 153.225 49.6496 153.225 50.1508C153.225 50.6519 153.154 51.0599 153.073 51.0482L153.067 51.0541ZM148.727 17.6512C148.57 18.0708 147.702 29.9005 147.702 31.6487C147.702 32.1207 147.498 32.1382 145.61 31.8119C144.963 31.7012 144.433 31.538 144.433 31.4448C144.433 31.3515 144.701 30.5124 145.027 29.5742C145.354 28.636 146.094 25.5707 146.676 22.7619C147.253 19.9531 147.777 17.4473 147.841 17.1909C147.917 16.8762 148.104 16.7305 148.442 16.7305C148.983 16.7305 149.024 16.8646 148.727 17.6396V17.6512ZM146.169 17.3949C146 17.762 145.237 21.0544 144.486 24.7082C143.431 29.7956 143.041 31.3515 142.802 31.3632C142.021 31.4098 140.233 31.2058 140.081 31.0601C139.988 30.9669 140.274 30.1686 140.722 29.2828C141.165 28.397 142.336 25.4192 143.315 22.6686C145.622 16.1885 145.564 16.3342 146.065 16.3342C146.566 16.3342 146.583 16.5149 146.175 17.4007L146.169 17.3949ZM143.723 17.0219C143.554 17.2783 142.336 20.5183 141.014 24.2187L138.613 30.9436L135.45 31.0601L136.609 29.2653C137.25 28.2747 138.998 24.9647 140.501 21.8994C142.685 17.4356 143.309 16.3285 143.629 16.3285C144.113 16.3285 144.119 16.41 143.723 17.0161V17.0219ZM136.697 32.4762C138.002 32.4762 138.13 32.5112 137.996 32.8317C137.908 33.0298 136.667 36.4505 135.234 40.4423L132.63 47.6975L131.535 47.715C130.935 47.7266 129.764 47.68 128.942 47.61L127.439 47.4877L127.841 46.9749C128.063 46.6951 129.816 43.3152 131.745 39.4633L135.246 32.4646H136.697V32.4762ZM125.901 47.6683C125.814 47.7207 124.789 47.8315 123.618 47.9131L121.491 48.0646L122.132 47.1671C122.488 46.6718 124.649 43.2336 126.944 39.5274L131.116 32.7851L132.281 32.6219C132.922 32.5287 133.475 32.482 133.51 32.517C133.597 32.6044 126.094 47.5517 125.901 47.6683ZM128.948 33.9389C128.622 34.4284 126.589 37.7209 124.416 41.264C122.249 44.8012 120.349 47.8431 120.204 48.0179C120.052 48.1927 119.359 48.4492 118.648 48.5949C117.943 48.7406 117.134 48.9095 116.854 48.9736L116.341 49.0902L116.883 48.5016C117.18 48.1753 119.697 44.6963 122.47 40.757C125.243 36.8235 127.573 33.5426 127.649 33.4727C127.725 33.3969 128.179 33.2746 128.657 33.1988L129.531 33.0531L128.942 33.9389H128.948ZM116.965 50.1974C117.745 49.9993 118.543 49.8594 118.736 49.8886C118.998 49.9294 117.961 51.7591 114.291 57.7089L109.502 65.4769L107.305 65.9256C104.148 66.5725 104.235 66.6074 105.261 65.1506C105.744 64.4687 108.255 60.9024 110.842 57.2311L115.549 50.5587L116.971 50.1974H116.965ZM108.319 67.062C108.407 67.0911 106.245 70.7449 103.513 75.1796L98.5435 83.2447L95.4966 83.8041C91.3254 84.5734 91.5291 84.62 92.6069 83.1049C93.1079 82.3997 95.6539 78.7926 98.2639 75.0863C100.874 71.3801 103.088 68.2624 103.175 68.1634C103.356 67.971 108.051 66.9687 108.325 67.062H108.319ZM95.9917 76.514C92.9681 80.7855 90.4165 84.3985 90.3291 84.5442C90.2417 84.6899 89.1814 85.1736 87.9754 85.6164C85.6451 86.4731 85.6044 86.4848 85.6044 86.31C85.6044 86.1759 97.1103 71.0013 97.7161 70.3311C98.0773 69.929 101.282 68.513 101.439 68.682C101.468 68.717 99.0211 72.2367 95.9917 76.5082V76.514ZM86.35 87.4521C87.6433 86.9801 88.727 86.6246 88.7561 86.6654C88.7853 86.7004 86.1812 90.4474 82.9653 94.987L77.122 103.239L74.6694 104.101C72.3701 104.913 71.2845 105.208 71.4127 104.987C71.5059 104.835 74.3722 101.018 77.7861 96.5079L83.9965 88.3029L86.3442 87.4463L86.35 87.4521ZM72.6769 106.1C74.3197 105.511 75.6946 105.057 75.7237 105.086C75.7878 105.15 64.2528 121.519 63.8392 121.95C63.6935 122.102 62.4875 122.586 61.1534 123.023C57.7978 124.124 56.7899 124.421 56.7899 124.311C56.7899 124.258 59.6912 120.377 63.2333 115.686L69.6766 107.16L72.671 106.094L72.6769 106.1ZM58.6659 125.202C60.6001 124.561 62.2138 124.066 62.2546 124.107C62.2954 124.147 59.5397 128.11 56.1316 132.918L49.9387 141.659L45.9598 142.853C43.7693 143.512 41.9574 144.048 41.9224 144.054C41.7768 144.06 42.3886 143.18 43.915 141.193C44.8238 140.01 47.7192 136.193 50.3525 132.708L55.1471 126.373L58.6659 125.202ZM50.7369 143.028C51.2787 142.813 62.3187 141.332 62.4469 141.461C62.4993 141.513 61.4622 143.285 60.1514 145.406C58.8348 147.527 57.1919 150.178 56.4986 151.303C52.1409 158.349 51.2088 159.782 51.0049 159.782C50.8767 159.782 48.0629 160.103 44.748 160.499C41.4331 160.889 38.4619 161.256 38.1473 161.315C37.7337 161.385 37.6172 161.344 37.7221 161.163C37.8036 161.023 39.9418 157.97 42.4702 154.374C44.9986 150.779 47.7949 146.793 48.6863 145.522C49.5776 144.252 50.4981 143.133 50.7428 143.034L50.7369 143.028ZM43.3032 162.23C47.0492 161.781 50.1369 161.437 50.1602 161.466C50.201 161.519 38.759 180.143 38.5726 180.33C38.5202 180.382 35.7297 180.702 32.3682 181.046C23.5654 181.938 23.0936 181.985 23.0936 181.909C23.0936 181.792 35.8112 163.774 36.155 163.407C36.4288 163.115 37.7629 162.894 43.3091 162.23H43.3032ZM28.8902 185.93C32.7993 187.27 36.0327 188.401 36.0735 188.441C36.1142 188.482 34.1917 188.995 31.7914 189.578C29.397 190.16 27.3522 190.632 27.2531 190.621C27.1541 190.615 23.5013 189.624 19.1378 188.43C13.8014 186.967 11.3254 186.204 11.5818 186.099C11.7857 186.011 14.1683 185.394 16.8715 184.712L21.7886 183.482L28.896 185.918L28.8902 185.93ZM28.1736 191.868C28.6921 191.868 43.7751 195.959 43.9965 196.163C44.0897 196.25 43.2741 196.786 42.1789 197.363C41.0836 197.94 40.134 198.4 40.0699 198.389C40 198.377 37.9668 197.928 35.5549 197.386C33.1372 196.85 29.3446 196.011 27.1191 195.533C24.8937 195.05 23.1518 194.589 23.2392 194.502C23.6587 194.094 27.8241 191.868 28.1795 191.868H28.1736ZM39.4058 199.135C39.4757 199.205 39.2484 199.781 38.9047 200.417C38.3746 201.396 38.1824 201.576 37.6814 201.605C37.0813 201.635 20.868 198.913 20.7108 198.756C20.6175 198.663 21.8235 195.737 22.0624 195.481C22.2197 195.318 39.1611 198.884 39.4116 199.135H39.4058ZM21.206 199.717C21.5089 199.782 25.3481 200.428 29.7291 201.163C34.1101 201.897 37.8212 202.567 37.9668 202.649C38.1183 202.736 38.5028 203.424 38.829 204.181L39.4175 205.562L38.8639 205.539C37.3375 205.475 22.6333 203.552 22.4935 203.394C22.4003 203.295 21.9517 202.404 21.4915 201.407L20.6583 199.607L21.2118 199.717H21.206ZM39.4931 206.471C40.0466 206.576 43.5188 209.344 43.5188 209.682C43.5188 209.776 43.4955 209.84 43.4664 209.822C43.4372 209.805 40.0991 209.554 36.0385 209.263C31.9837 208.971 28.5347 208.633 28.3775 208.511C27.2298 207.637 23.7052 204.671 23.7576 204.618C23.8217 204.554 38.4387 206.273 39.4931 206.471ZM37.7804 210.189L45.0101 210.708L47.7891 212.241C49.3154 213.086 50.6554 213.855 50.7603 213.96C50.9642 214.152 49.0941 214.152 41.8818 213.948L37.8969 213.837L34.1567 211.821C32.1002 210.714 30.4457 209.776 30.4865 209.741C30.5214 209.706 33.8072 209.904 37.7804 210.189ZM52.706 214.95L56.7899 216.629C59.0328 217.549 60.8447 218.336 60.8098 218.365C60.7748 218.4 58.6483 218.563 56.0792 218.732C53.51 218.901 51.1739 219.035 50.8826 219.024C50.5971 219.012 48.1853 218.12 45.5229 217.031L40.6874 215.055L52.7002 214.944L52.706 214.95ZM54.7509 219.799C55.5956 219.723 57.8095 219.566 59.6796 219.443L63.076 219.222L68.0046 220.807C70.7136 221.681 72.9333 222.45 72.9333 222.514C72.9333 222.578 71.2554 222.934 69.2047 223.295C67.154 223.656 65.4296 223.942 65.3713 223.93C65.313 223.919 62.5576 223.015 59.2427 221.92L53.2187 219.933L54.7509 219.799ZM75.3801 223.336C76.1608 223.336 87.055 226.255 86.8802 226.419C86.7929 226.5 85.8141 226.943 84.7014 227.403C83.5887 227.864 82.4409 228.237 82.1496 228.225C81.4913 228.208 68.2143 224.723 68.3367 224.6C68.4648 224.466 74.7801 223.336 75.3801 223.336ZM86.9384 227.829L89.3795 226.856L95.8169 228.248C99.3532 229.018 102.284 229.647 102.318 229.659C102.353 229.67 101.905 230.224 101.317 230.9C100.204 232.182 100.029 232.246 98.6775 231.902C98.2813 231.803 95.112 231.121 91.6282 230.381C88.1444 229.647 85.1149 228.989 84.8994 228.924C84.6197 228.843 85.2198 228.517 86.9442 227.829H86.9384ZM104.352 230.113C104.783 230.003 117.477 232.182 117.78 232.415C117.937 232.532 118.124 233.208 118.2 233.907C118.334 235.16 118.328 235.183 117.85 235.16C116.97 235.119 102.354 232.596 102.214 232.462C102.056 232.304 103.956 230.206 104.346 230.107L104.352 230.113ZM118.205 222.217C118.13 221.489 118.013 220.737 117.937 220.55C117.821 220.247 117.943 220.23 119.05 220.352C120.28 220.492 120.314 220.515 121.893 222.135C122.773 223.039 123.524 223.86 123.559 223.965C123.647 224.21 122.522 224.169 120.221 223.843C119.207 223.697 118.374 223.575 118.363 223.563C118.351 223.552 118.281 222.945 118.205 222.217ZM123.513 221.932L122.272 220.632L123.326 220.766C124.177 220.871 124.981 221.261 127.41 222.747C129.077 223.767 130.475 224.635 130.527 224.682C130.632 224.787 128.861 224.735 127.037 224.577C125.826 224.472 125.622 224.391 125.22 223.849C124.969 223.511 124.2 222.648 123.519 221.932H123.513ZM129.694 225.614L132.403 225.824L135.409 227.666C137.064 228.68 138.45 229.548 138.497 229.589C138.607 229.694 138.048 229.665 133.813 229.344L130.236 229.076L128.564 227.281C127.643 226.296 126.909 225.469 126.938 225.445C126.962 225.422 128.203 225.498 129.694 225.614ZM136.353 230.375L140.349 230.696L143.14 232.427C144.678 233.377 145.977 234.204 146.035 234.262C146.169 234.396 145.919 234.385 139.738 233.919L134.529 233.528L132.904 231.856C130.941 229.834 130.725 229.927 136.353 230.375ZM141.73 234.903L147.905 235.393L150.615 237.054C152.106 237.963 153.359 238.749 153.405 238.79C153.562 238.936 151.547 238.825 145.045 238.318L138.607 237.817L136.994 236.197C136.102 235.305 135.415 234.542 135.462 234.501C135.508 234.46 138.322 234.641 141.719 234.909L141.73 234.903ZM153.219 237.333C151.646 236.354 150.364 235.539 150.364 235.515C150.364 235.469 155.881 235.562 159.452 235.667L161.497 235.725L165.581 237.52C167.83 238.505 169.706 239.35 169.752 239.396C169.857 239.495 167.847 239.466 161.136 239.262L156.079 239.111L153.225 237.333H153.219ZM167.958 237.584C165.674 236.553 163.88 235.69 163.973 235.667C164.066 235.643 166.164 235.521 168.628 235.399L173.108 235.177L184.375 238.965L182.126 239.093C180.891 239.163 178.13 239.274 175.997 239.338L172.117 239.455L167.958 237.584ZM175.695 234.985C175.695 234.851 181.998 233.948 182.866 233.954C183.39 233.954 196.114 237.357 196.3 237.543C196.353 237.596 196.301 237.642 196.178 237.642C196.056 237.642 193.953 237.916 191.494 238.254C189.042 238.592 186.892 238.86 186.729 238.849C186.251 238.819 175.695 235.125 175.695 234.985ZM184.835 233.342C184.923 233.266 186.1 232.858 187.463 232.433L189.933 231.657L197.675 233.336C201.934 234.256 205.453 235.043 205.488 235.078C205.523 235.113 205.389 235.195 205.179 235.253C204.975 235.311 203.414 235.783 201.713 236.296C200.012 236.809 198.537 237.223 198.444 237.211C197.745 237.153 184.713 233.441 184.835 233.336V233.342ZM198.596 232.724C194.506 231.838 191.133 231.081 191.098 231.046C190.952 230.9 193.853 228.855 194.209 228.849C194.879 228.843 211.04 231.605 211.04 231.727C211.04 231.791 210.143 232.456 209.047 233.208C207.952 233.959 207.008 234.56 206.956 234.548C206.898 234.536 206.67 234.484 206.443 234.425C206.216 234.373 202.691 233.604 198.602 232.718L198.596 232.724ZM195.135 228.138L194.454 228.01L194.593 226.745C194.669 226.052 194.797 225.41 194.873 225.329C195.03 225.16 212.275 227.2 212.519 227.415C212.607 227.491 212.508 228.283 212.31 229.175C212.007 230.498 211.867 230.801 211.541 230.83C211.232 230.859 199.009 228.849 195.135 228.138ZM222.406 200.3C222.499 200.271 222.604 200.51 222.639 200.574C222.895 201.034 223.041 201.576 223.134 202.089C223.088 201.833 223.134 202.107 223.152 202.159C223.163 202.217 223.175 202.276 223.192 202.334C223.192 202.351 223.198 202.369 223.204 202.392C223.215 202.439 223.227 202.485 223.239 202.532C223.256 202.59 223.268 202.643 223.285 202.701C223.285 202.713 223.297 202.748 223.309 202.777C223.32 202.812 223.332 202.847 223.332 202.858C223.35 202.917 223.367 202.969 223.384 203.027C223.513 203.429 223.647 203.826 223.781 204.228C223.781 204.018 223.903 204.088 224.049 204.321C224.323 204.752 224.462 205.335 224.544 205.836C224.544 205.865 224.555 205.889 224.561 205.912C224.748 206.366 225.091 207.311 225.435 208.313C225.86 209.548 226.251 210.696 226.315 210.865C226.373 211.017 226.449 211.337 226.496 211.605C226.589 211.827 226.67 212.054 226.758 212.276C226.758 212.276 226.769 212.299 226.775 212.299C226.868 212.357 226.985 212.678 227.061 213.033C227.072 213.062 227.084 213.086 227.096 213.115C227.183 213.354 227.27 213.598 227.352 213.837C227.375 213.872 227.404 213.942 227.428 213.954C227.538 214.024 227.568 214.164 227.515 214.28C227.55 214.373 227.579 214.461 227.614 214.554C227.719 214.566 227.754 214.653 227.69 214.764C227.742 214.915 227.8 215.067 227.853 215.218C227.899 215.265 227.917 215.312 227.899 215.352C228.558 217.2 229.228 219.041 229.979 220.859C230.113 221.18 230.51 221.99 230.393 222.345C230.364 222.427 230.335 222.462 230.3 222.468C230.335 222.613 230.358 222.718 230.34 222.718C230.288 222.718 230.207 222.602 230.154 222.462C230.113 222.351 229.915 221.797 229.671 221.122C228.599 218.429 227.678 215.685 226.63 212.981C225.686 210.533 224.654 208.138 224.078 205.586C224.072 205.609 224.078 205.65 224.06 205.656C223.973 205.685 223.839 205.399 223.827 205.382C223.705 205.154 223.606 204.892 223.53 204.642C223.116 203.319 222.645 202.025 222.4 200.656C222.394 200.621 222.336 200.329 222.429 200.3H222.406ZM220.757 195.224C221.474 197.241 222.039 198.913 222.004 198.948C221.969 198.983 221.788 198.709 221.602 198.348C221.206 197.59 214.896 179.968 214.99 179.875C215.164 179.7 216.277 182.655 220.757 195.224ZM206.746 156.571C206.944 156.88 210.556 166.775 212.683 172.841C213.341 174.718 213.37 175.394 212.717 173.64C212.176 172.177 206.723 156.903 206.606 156.513C206.548 156.321 206.606 156.338 206.746 156.571ZM206.793 159.526C208.336 163.885 210.014 168.616 210.515 170.05C211.016 171.484 211.366 172.649 211.284 172.643C211.203 172.637 209.892 171.594 208.377 170.33L205.616 168.022L202.278 157.76C200.442 152.113 198.969 147.463 199.009 147.428C199.05 147.387 200.186 148.314 201.532 149.479L203.985 151.6L206.793 159.52V159.526ZM199.435 138.827C201.427 144.438 203.029 149.065 202.988 149.106C202.948 149.147 201.864 148.29 200.588 147.195C199.312 146.099 198.246 145.19 198.217 145.179C198.095 145.109 191.669 125.144 191.739 125.074C191.815 124.998 192.391 125.494 194.786 127.69L195.805 128.623L199.435 138.827ZM191.349 116.1C193.306 121.612 194.885 126.146 194.85 126.175C194.821 126.204 193.918 125.441 192.852 124.48L190.912 122.731L189.222 117.609C185.832 107.324 184.521 103.169 184.678 103.227C184.765 103.262 185.505 103.915 186.315 104.684L187.789 106.082L191.349 116.106V116.1ZM182.662 91.6129C184.025 95.4473 185.534 99.713 186.024 101.088C186.513 102.464 186.845 103.588 186.764 103.582C186.688 103.582 185.971 102.959 185.173 102.201L183.728 100.832L180.716 91.5605C179.056 86.4615 177.652 82.1375 177.588 81.9569C177.524 81.7762 178.083 82.2191 178.829 82.9475C179.574 83.6759 180.186 84.3519 180.186 84.4568C180.186 84.5617 181.299 87.7784 182.662 91.6129ZM172.549 63.0178C172.619 63.2509 173.685 66.2869 174.92 69.7717C176.155 73.2565 177.611 77.3707 178.159 78.9149C178.706 80.4592 179.132 81.7238 179.108 81.7179C178.835 81.6888 176.51 79.2121 176.51 78.9499C176.51 78.6877 172.7 66.7706 170.871 61.287C170.813 61.118 171.139 61.3452 171.599 61.7881C172.054 62.231 172.484 62.7847 172.554 63.0119L172.549 63.0178ZM164.509 41.025C164.695 41.1765 164.975 41.7244 165.132 42.2488C165.29 42.7733 166.769 46.9632 168.412 51.5669C170.055 56.1647 171.372 59.9583 171.337 59.9933C171.162 60.1681 169.799 58.4607 169.676 57.9188C169.56 57.406 164.631 41.9982 164.288 41.06C164.189 40.7978 164.223 40.7977 164.509 41.025ZM163.099 36.5904C163.827 38.6241 163.915 39.0845 163.484 38.56C163.251 38.2745 162.167 34.6965 162.284 34.5799C162.324 34.5391 162.691 35.4423 163.099 36.5904ZM158.188 25.2794C158.712 26.9344 159.825 30.3784 160.658 32.9366C161.485 35.4949 162.109 37.5869 162.027 37.5869C161.946 37.5869 161.59 37.3363 161.229 37.0274C160.646 36.5321 160.524 36.2232 160.157 34.4226C159.93 33.2979 159.143 30.1394 158.409 27.4063C157.675 24.6674 157.104 22.3948 157.151 22.354C157.192 22.3132 157.658 23.6302 158.188 25.2852V25.2794ZM155.264 19.6267C155.264 19.9647 156.184 23.671 157.308 27.8551C158.433 32.045 159.353 35.5764 159.353 35.7046C159.353 35.8328 159.283 35.9377 159.202 35.9377C159.062 35.9319 157.501 35.1568 157.343 35.0111C157.302 34.9762 157.151 33.8631 157 32.5345C156.854 31.2058 156.265 27.5987 155.695 24.5218C155.124 21.4449 154.698 18.8808 154.745 18.8284C154.966 18.6069 155.269 19.0615 155.269 19.6209L155.264 19.6267ZM153.283 13.135C153.329 13.0884 153.562 13.8168 153.795 14.755C154.028 15.6932 154.285 16.6198 154.355 16.8063C154.483 17.1384 154.151 17.2958 153.964 16.9927C153.813 16.7422 153.189 13.2224 153.283 13.1291V13.135ZM153.015 17.9659C153.335 18.1408 153.423 18.3913 153.423 19.1722C153.423 19.9531 155.433 31.6312 155.98 34.0613C156.102 34.6149 156.085 34.6149 154.541 34.0147L153.318 33.5368L153.382 31.6254C153.417 30.5765 153.259 27.2141 153.026 24.1605C152.496 17.2433 152.502 17.692 153.009 17.9659H153.015ZM151.721 11.0196C151.78 11.2993 152.036 12.6105 152.286 13.9333C152.712 16.1769 152.723 16.3342 152.391 16.3342C152.118 16.3342 152.007 16.107 151.919 15.3611C151.756 13.98 151.593 10.4077 151.721 11.0196ZM150.271 9.23064C150.3 9.25977 150.434 10.7399 150.568 12.5173C150.702 14.2947 150.778 15.769 150.737 15.7982C150.696 15.8273 150.504 15.8156 150.306 15.769C150.026 15.7049 149.95 15.4776 149.95 14.7317C149.95 13.473 150.201 9.1607 150.271 9.2248V9.23064ZM149.944 23.2164C150.148 19.9764 150.358 17.29 150.399 17.2492C150.446 17.2026 150.673 17.2142 150.906 17.2783C151.273 17.3715 151.308 17.4822 151.174 18.0883C151.081 18.4904 151.22 21.6139 151.5 25.4775C151.768 29.1604 151.989 32.3772 151.989 32.6336C151.989 32.9424 151.879 33.0881 151.634 33.0765C151.238 33.0532 149.071 32.4879 148.96 32.3771C148.919 32.3363 149.041 31.5904 149.228 30.7105C149.414 29.8306 149.735 26.4623 149.939 23.2223L149.944 23.2164ZM149.036 8.67123C149.088 8.56051 149.082 9.02087 149.036 9.69103C148.983 10.367 148.878 11.9054 148.809 13.1117C148.68 15.2504 148.663 15.3087 148.191 15.3087C147.923 15.3087 147.707 15.2212 147.707 15.1105C147.707 14.8308 148.931 8.91015 149.042 8.66539L149.036 8.67123ZM146.554 14.7492C146.455 15.1047 145.773 15.2503 145.598 14.9531C145.499 14.7841 147.55 8.95674 147.667 9.07329C147.731 9.13739 146.816 13.7877 146.554 14.7492ZM146.21 9.45792C146.239 9.48705 145.832 10.7283 145.301 12.2084C144.451 14.5802 144.282 14.9007 143.874 14.9007C143.443 14.9007 143.501 14.7317 144.783 12.1502C145.54 10.6409 146.175 9.42295 146.21 9.45792ZM141.823 14.6443C141.986 14.3938 142.557 13.473 143.093 12.5989C143.629 11.7306 144.107 11.0138 144.154 11.0138C144.2 11.0138 143.775 11.9345 143.21 13.0592C142.552 14.3762 142.068 15.1047 141.858 15.1047C141.567 15.1047 141.561 15.0523 141.823 14.6443ZM141.375 16.9986C141.13 17.3657 139.458 20.6524 137.658 24.3062C135.864 27.96 134.349 30.9844 134.302 31.0369C134.256 31.0835 133.65 31.165 132.962 31.2175C131.535 31.3224 131.523 31.4739 133.102 29.3119C133.679 28.5252 135.7 25.3551 137.6 22.2607C139.493 19.1722 141.142 16.5732 141.258 16.4916C141.742 16.1536 141.794 16.375 141.375 16.9986ZM138.648 17.9659C138.695 17.9659 138.695 18.0359 138.648 18.1175C137.693 19.7142 130.475 31.3865 130.376 31.4914C130.3 31.5729 129.828 31.7011 129.321 31.7827L128.407 31.9284L129.467 30.6172C130.049 29.8946 132.333 26.7537 134.541 23.636C136.749 20.5183 138.596 17.9659 138.642 17.9659H138.648ZM129.181 28.8224C130.51 27.1208 131.651 25.728 131.71 25.728C131.768 25.728 131.593 26.0252 131.313 26.3924C131.04 26.7595 129.968 28.263 128.937 29.7431C127.842 31.3107 126.886 32.4704 126.641 32.5403C126.134 32.6744 125.907 33.0065 129.181 28.8224ZM113.201 49.8652C113.358 49.638 116.079 46.0599 119.248 41.9108C124.235 35.3783 125.493 33.8806 125.756 34.1545C125.796 34.1953 119.72 42.9015 115.345 49.0669C115.211 49.2534 114.611 49.603 114.005 49.8419C112.927 50.2673 112.916 50.2673 113.201 49.8652ZM112.689 51.5494C113.294 51.2988 113.79 51.1415 113.79 51.1939C113.79 51.2464 111.308 54.8069 108.273 59.1017L102.755 66.9163L101.258 67.4757C99.6038 68.0876 99.3998 68.1342 99.5979 67.8196C99.6678 67.703 102.394 64.0958 105.657 59.801C111.488 52.1263 111.605 51.9864 112.689 51.5494ZM97.1686 69.0375C97.2909 68.8743 99.3533 66.217 101.742 63.1285C105.791 57.9013 107.294 56.0365 106.286 57.5108C106.053 57.8488 104.014 60.5585 101.748 63.5363C99.4813 66.5142 97.4715 69.0374 97.285 69.1423C97.0054 69.2938 96.9821 69.2764 97.1686 69.0375ZM83.4081 86.6771C84.0081 85.9195 86.7229 82.4347 89.4435 78.9382C94.1624 72.8602 94.9139 71.957 95.0829 72.1435C95.2169 72.2833 84.0022 86.9101 83.3148 87.4987C82.2195 88.4311 82.2546 88.1398 83.4081 86.6829V86.6771ZM70.2009 103.699C71.7622 101.694 74.5353 98.1104 76.3646 95.7387C79.5688 91.5896 80.1106 90.9777 81.002 90.4707C81.3399 90.2784 81.3748 90.2842 81.1884 90.529C81.0661 90.6863 78.3687 94.2353 75.1995 98.4135C72.0244 102.592 69.2047 106.158 68.9367 106.333C68.6629 106.508 68.1969 106.811 67.9056 106.997C67.6085 107.19 68.6454 105.704 70.2067 103.693L70.2009 103.699ZM58.596 118.664C61.4972 114.923 64.0838 111.572 64.3518 111.205C64.6139 110.843 65.383 110.156 66.0588 109.684L67.288 108.821L64.748 112.143C63.3498 113.973 61.072 116.956 59.6796 118.774C58.2872 120.593 56.6617 122.737 56.0558 123.541C55.4558 124.346 54.6927 125.196 54.3606 125.429C53.7139 125.89 53.3119 125.977 53.3119 125.657C53.3119 125.546 55.683 122.399 58.5843 118.658L58.596 118.664ZM41.27 142.131C41.573 141.49 41.9691 140.907 42.3652 140.324C42.3652 140.324 42.3652 140.313 42.3652 140.307C42.2895 140.173 42.3012 140.132 42.3944 140.219C42.406 140.225 42.4235 140.219 42.4352 140.219C42.6274 139.94 42.8197 139.66 43.0003 139.369C43.577 138.425 44.1362 137.475 44.8353 136.618C45.5636 135.726 46.3093 134.847 47.0375 133.955C47.3812 133.53 47.725 133.098 48.092 132.69C48.2551 132.51 48.4241 132.335 48.5873 132.16C48.663 132.078 48.727 131.991 48.8086 131.921C48.8319 131.898 48.8319 131.904 48.8494 131.892C48.9135 131.781 49.0066 131.7 49.0765 131.589C49.1173 131.531 49.1466 131.467 49.1873 131.408C49.4204 130.965 49.5893 130.744 49.7816 130.622C49.9156 130.447 50.0495 130.272 50.1894 130.103C50.2127 130.027 50.3059 129.905 50.4807 129.73C50.5098 129.695 50.5388 129.648 50.5621 129.625C50.5621 129.619 50.568 129.613 50.5738 129.608C50.8593 129.095 51.2089 128.582 51.6341 128.18C51.7798 128.04 51.9138 127.953 52.0478 127.953C52.0478 127.947 52.0594 127.935 52.0653 127.929C52.0886 127.9 52.4497 127.492 52.6245 127.399C52.6944 127.335 52.8109 127.23 52.8633 127.271C52.9332 127.323 52.7876 127.603 52.776 127.615C52.7294 127.714 52.6653 127.801 52.6128 127.894C52.5488 128.093 52.4614 128.285 52.3565 128.471C52.2109 128.722 52.0477 128.961 51.8671 129.194C51.471 129.806 51.0399 130.4 50.5855 130.971C50.568 130.989 50.5563 131.006 50.5388 131.03C50.5155 131.065 50.4923 131.094 50.469 131.129C50.3874 131.239 50.3116 131.35 50.2359 131.461C50.0844 131.676 49.9331 131.898 49.7816 132.108C49.3505 132.702 48.8901 133.285 48.3658 133.798C48.3425 133.821 48.1736 134.002 48.0862 133.978C47.7832 134.439 47.4512 134.882 47.0725 135.272C46.9618 135.447 46.8103 135.657 46.6064 135.872C46.2743 136.228 46.0239 136.536 46.0472 136.56C46.0705 136.583 45.2665 137.684 44.2703 139.007C43.7285 139.724 43.2333 140.365 42.8663 140.825C42.8139 140.919 42.7556 141.018 42.7031 141.111C42.5633 141.362 42.3886 141.601 42.208 141.822C42.0682 141.997 41.9167 142.177 41.7419 142.317C41.6604 142.376 41.5846 142.434 41.5555 142.317C41.5497 142.294 41.5788 142.242 41.5905 142.201C41.3633 142.428 41.037 142.661 41.2875 142.137L41.27 142.131ZM47.7541 143.739C48.3774 143.553 48.5813 143.541 48.4823 143.71C48.4007 143.838 47.5618 145.05 46.6064 146.396C45.2665 148.296 36.0501 161.297 35.8462 161.577C35.7063 161.769 26.6007 164.164 26.7055 163.984C26.7754 163.861 27.8124 162.474 29.0125 160.901C30.2068 159.328 33.0557 155.557 35.3394 152.521C37.6231 149.485 39.7321 146.758 40.0234 146.461C40.536 145.942 41.0719 145.755 47.7599 143.728L47.7541 143.739ZM25.3539 162.265C25.7675 161.775 26.1113 161.227 26.4551 160.68C26.5017 160.563 26.5133 160.435 26.5774 160.312C26.7754 159.963 27.0318 159.601 27.3231 159.304C27.5153 158.984 27.7018 158.663 27.9057 158.354C28.7854 157.037 29.8398 155.901 30.8244 154.666C31.8323 153.407 32.7702 152.09 33.8363 150.878C34.9315 149.636 36.0618 148.448 37.0813 147.148C37.1221 147.096 37.5474 146.525 37.6814 146.589C37.7338 146.612 37.7279 146.688 37.6987 146.775C37.7104 146.775 37.7395 146.758 37.7337 146.781C37.291 148.576 36.0384 150.109 34.8442 151.466C33.4576 153.04 32.2167 154.66 30.9991 156.373C30.3233 157.317 29.6243 158.244 28.9135 159.164C28.3135 159.945 27.6319 160.697 27.2008 161.594C26.8396 162.346 26.4551 163.063 25.89 163.686C25.3773 164.252 24.981 164.415 24.48 163.739C24.2703 163.453 25.1849 162.457 25.3422 162.27L25.3539 162.265ZM24.1654 167.55C24.2586 167.55 24.2937 167.48 24.2412 167.399C24.1888 167.317 24.3461 167.008 24.585 166.717C24.952 166.28 25.8083 165.965 29.5776 164.904C32.0827 164.193 34.1683 163.657 34.2149 163.698C34.3023 163.785 21.8643 181.518 21.3633 182.025C21.2177 182.177 18.9455 182.841 16.3181 183.5C13.6906 184.164 11.4245 184.706 11.2788 184.706C10.9351 184.712 11.2089 184.216 12.0362 183.319C12.3799 182.946 12.6653 182.561 12.6653 182.462C12.6653 182.363 12.8692 182.136 13.1197 181.967C13.3702 181.792 13.5042 181.647 13.4168 181.647C13.3294 181.647 13.3586 181.53 13.4752 181.39C13.5917 181.25 14.4364 180.149 15.3452 178.943C16.254 177.736 17.0988 176.81 17.2153 176.88C17.3376 176.955 17.3668 176.909 17.2794 176.775C17.1338 176.542 19.9476 172.655 20.2622 172.655C20.3495 172.655 20.4253 172.538 20.4253 172.393C20.4253 172.247 20.6991 171.827 21.037 171.46C21.3749 171.093 21.6488 170.743 21.6488 170.685C21.6488 170.475 23.9906 167.544 24.1537 167.544L24.1654 167.55ZM5.5055 187.55C5.5055 187.55 5.54036 187.497 5.55784 187.468C5.51706 187.392 5.61617 187.206 5.63948 187.148C5.86086 186.676 6.21033 186.227 6.57735 185.86C6.68804 185.749 6.79877 185.633 6.90946 185.522C6.93277 185.498 6.95599 185.475 6.9793 185.452C7.02008 185.411 7.06097 185.37 7.09593 185.324C7.29983 185.102 7.49779 184.881 7.70169 184.659C7.9289 184.403 8.1562 184.135 8.38341 183.878C8.70965 183.074 9.36788 182.328 9.89803 181.728C10.434 181.116 10.9351 180.481 11.4128 179.828C11.64 179.345 12.0245 178.861 12.3333 178.523C12.4498 178.348 12.5779 178.185 12.6944 178.01C12.6944 178.004 12.7003 177.993 12.7061 177.987C12.7294 177.946 12.8868 177.713 13.0732 177.462C13.3645 177.031 13.6615 176.6 13.9586 176.175C13.9411 175.633 14.3722 175.097 14.6868 174.7C14.914 174.415 15.1296 174.129 15.4325 174.17C15.4442 174.158 15.45 174.147 15.4559 174.135C15.5899 173.966 15.7471 173.82 15.8811 173.651C15.9685 173.541 16.0559 173.442 16.1433 173.354C17.6347 171.571 19.231 169.881 20.8739 168.232C20.9438 168.104 21.0253 167.97 21.1244 167.836C21.2059 167.41 22.1614 166.082 22.4643 166.134C22.7381 166.181 22.9887 166.198 23.2684 166.198C23.3324 166.198 23.0877 166.658 22.9129 166.961C22.8488 167.142 22.7091 167.369 22.5401 167.597C22.5984 167.841 22.0566 168.616 21.6429 169.053C21.6138 169.1 21.5904 169.147 21.5555 169.199C21.5555 169.199 21.5555 169.199 21.5555 169.205C21.5729 169.205 21.5788 169.205 21.5963 169.205C21.7011 169.217 21.404 169.747 21.404 169.753C20.5418 171.221 19.4582 172.521 18.3279 173.785C17.1045 175.155 16.0094 176.559 14.9258 178.045C13.9237 179.42 12.9101 180.784 11.8906 182.142C11.1973 183.074 10.6672 184.205 9.7292 184.927C9.47287 185.126 9.11745 185.201 8.80868 185.172C8.78538 185.195 8.762 185.219 8.7387 185.242C8.66879 185.312 8.59896 185.382 8.52905 185.452C8.49992 185.481 8.47654 185.51 8.44741 185.539C8.16777 185.842 7.89984 186.157 7.62602 186.472C7.53864 186.577 7.4396 186.67 7.33473 186.757C7.29978 186.781 7.26486 186.798 7.22991 186.821C7.10174 186.862 7.15995 186.705 7.17743 186.641C7.18325 186.617 7.20076 186.588 7.21242 186.565C6.69392 187.014 6.15793 187.439 5.59283 187.829C5.51709 187.882 5.43549 187.952 5.40636 187.829C5.38888 187.754 5.47623 187.608 5.51118 187.544L5.5055 187.55ZM6.57152 188.494L9.48442 186.711L15.7238 188.401C19.1552 189.327 22.8605 190.329 23.9558 190.621C25.051 190.912 25.9481 191.198 25.9423 191.256C25.9423 191.314 24.8354 191.979 23.4897 192.742C22.1439 193.5 20.8855 194.117 20.6874 194.106C20.1573 194.082 3.8801 190.504 3.75776 190.382C3.6995 190.324 4.96943 189.479 6.57152 188.494ZM2.62744 191.338C2.72065 191.186 5.47044 191.699 11.3778 192.975C16.1142 194.001 20.0466 194.892 20.1165 194.956C20.1806 195.02 19.9301 195.801 19.5514 196.693C18.9281 198.161 18.8116 198.307 18.2698 198.336C17.6115 198.365 1.45074 195.638 1.28179 195.463C1.18275 195.364 2.33615 191.839 2.62744 191.338ZM1.43312 196.524C1.43312 196.472 5.31897 197.083 10.067 197.876L18.7009 199.327L19.6621 201.168C20.1922 202.182 20.6293 203.074 20.6351 203.161C20.6351 203.243 20.437 203.307 20.1807 203.295C19.7962 203.278 4.06643 201.332 3.95574 201.291C3.89166 201.267 1.43896 196.629 1.43896 196.53L1.43312 196.524ZM8.34842 204.945C6.59485 203.54 5.1734 202.375 5.18505 202.357C5.1967 202.34 8.80287 202.753 13.1955 203.278C18.5902 203.925 21.3225 204.333 21.6079 204.537C22.6508 205.271 26.3326 208.33 26.3443 208.464C26.3443 208.546 26.286 208.604 26.2044 208.593C26.1229 208.575 22.7847 208.325 18.794 208.033L11.5351 207.497L8.34842 204.945ZM18.3396 211.18C15.7821 209.834 13.6906 208.68 13.6906 208.622C13.6906 208.563 16.8716 208.738 20.7691 209L27.8474 209.484L31.7331 211.611C33.8712 212.783 35.6656 213.785 35.718 213.837C35.8345 213.954 29.8631 213.895 25.8375 213.738L22.9771 213.627L18.3338 211.174L18.3396 211.18ZM31.8729 217.299L25.6452 214.775L37.6172 214.758L43.0061 216.949C45.9714 218.155 48.3775 219.164 48.3541 219.187C48.3308 219.21 46.2045 219.373 43.6295 219.548C41.0545 219.723 38.7591 219.857 38.5261 219.845C38.2931 219.834 35.3043 218.692 31.8788 217.299H31.8729ZM41.1535 220.725C41.1885 220.69 43.344 220.521 45.9365 220.352L50.6555 220.043L56.6384 221.984C62.872 224.006 63.7926 224.327 63.4081 224.35C63.2799 224.356 61.7186 224.641 59.9359 224.973C58.1532 225.311 56.5103 225.579 56.2831 225.574C55.8112 225.556 41.0545 220.83 41.1535 220.731V220.725ZM76.1025 230.842L71.5875 229.659C69.1057 229.006 65.2199 227.998 62.9536 227.409C60.6874 226.821 58.8581 226.32 58.8872 226.29C58.9164 226.261 60.5244 225.947 62.4527 225.597L65.9597 224.956L73.0731 226.827C76.9822 227.852 80.3087 228.761 80.4602 228.843C80.6408 228.942 80.2505 229.192 79.3359 229.56C78.5669 229.868 77.5182 230.282 77.0172 230.48L76.0967 230.842H76.1025ZM97.2444 235.323C97.1861 235.34 93.5566 234.589 89.1756 233.645C84.7946 232.701 80.635 231.821 79.9301 231.687C79.2252 231.553 78.6541 231.384 78.6541 231.314C78.6541 231.244 79.627 230.783 80.8155 230.3L82.9828 229.408L90.4689 230.987C94.5877 231.856 98.3104 232.654 98.7415 232.765L99.5222 232.969L98.4327 234.128C97.8327 234.769 97.2968 235.305 97.2385 235.323H97.2444ZM118.852 238.965C118.724 239.052 99.2892 235.731 99.2951 235.62C99.2951 235.556 99.7436 235.002 100.285 234.391L101.27 233.277L109.729 234.67C115.164 235.568 118.264 236.168 118.415 236.343C118.538 236.494 118.706 237.141 118.776 237.776C118.852 238.411 118.887 238.948 118.858 238.965H118.852ZM118.788 226.145C118.532 224.28 118.165 224.42 122.027 224.886C125.045 225.247 124.841 225.142 126.909 227.473C127.585 228.231 128.01 228.843 127.859 228.825C127.708 228.814 125.651 228.557 123.291 228.266L119.004 227.73L118.782 226.145H118.788ZM119.377 230.236C119.26 229.42 119.196 228.715 119.237 228.668C119.307 228.581 128.319 229.63 128.908 229.787C129.076 229.833 129.886 230.609 130.708 231.506L132.199 233.143L131.523 233.126C131.151 233.114 128.453 232.8 125.534 232.421C122.61 232.042 120.081 231.733 119.901 231.727C119.662 231.722 119.528 231.343 119.371 230.236H119.377ZM119.953 234.093C119.837 233.295 119.761 232.625 119.784 232.602C119.808 232.578 122.86 232.934 126.566 233.4L133.3 234.245L136.318 237.438L135.631 237.415C135.252 237.403 131.617 236.978 127.556 236.465L120.169 235.539L119.953 234.093ZM139.994 241.704C139.913 241.692 135.578 241.139 130.364 240.48C125.15 239.822 120.85 239.245 120.81 239.204C120.693 239.087 120.309 236.582 120.39 236.494C120.431 236.453 124.223 236.891 128.826 237.456L137.192 238.487L138.672 239.95C139.487 240.754 140.151 241.482 140.151 241.57C140.151 241.657 140.081 241.716 140 241.704H139.994ZM150.772 242.625L142.499 241.937L140.973 240.41C140.134 239.571 139.487 238.848 139.54 238.802C139.592 238.761 143.169 238.994 147.498 239.332L155.363 239.944L158.019 241.576C159.481 242.473 160.711 243.242 160.763 243.283C160.926 243.435 158.98 243.301 150.772 242.625ZM169.461 243.761C167.212 243.685 164.917 243.61 164.352 243.592C163.454 243.569 163.006 243.365 160.716 241.955C159.277 241.069 158.037 240.282 157.961 240.2C157.879 240.119 160.984 240.113 164.864 240.195L171.913 240.335L175.695 241.972C177.774 242.875 179.609 243.685 179.778 243.784C180.122 243.982 175.694 243.971 169.461 243.755V243.761ZM191.721 243.761C188.581 243.878 185.307 244.006 184.451 244.052L182.889 244.134L174.407 240.393L176.225 240.265C177.227 240.195 180.047 240.066 182.488 239.985L186.933 239.833L192.228 241.64C195.141 242.636 197.506 243.47 197.477 243.499C197.448 243.528 194.861 243.644 191.715 243.755L191.721 243.761ZM211.838 241.931C211.681 241.931 209.123 242.252 206.163 242.648C203.198 243.044 200.536 243.359 200.239 243.353C199.773 243.347 189.263 239.839 189.047 239.618C188.977 239.548 195.211 238.65 197.967 238.336C198.963 238.219 199.819 238.406 205.511 239.967C211.552 241.622 212.543 241.931 211.844 241.931H211.838ZM218.834 240.259C216.388 240.952 214.296 241.512 214.191 241.5C214.087 241.488 213.259 241.267 212.362 241.016C211.465 240.76 208.616 239.991 206.029 239.297C203.443 238.604 201.159 237.969 200.949 237.887C200.681 237.776 201.654 237.415 204.229 236.652L207.888 235.574L215.537 237.24C219.744 238.155 223.21 238.93 223.233 238.953C223.256 238.977 221.276 239.571 218.829 240.265L218.834 240.259ZM227.958 236.448C226.653 237.31 225.412 238.097 225.202 238.202C224.928 238.342 222.656 237.928 217.116 236.727C212.881 235.812 209.356 235.008 209.286 234.938C209.082 234.734 212.991 232.118 213.498 232.118C213.76 232.118 217.512 232.718 221.847 233.447C226.175 234.175 229.857 234.798 230.026 234.828C230.195 234.857 229.263 235.585 227.952 236.442L227.958 236.448ZM231.756 232.17C231.43 233.266 231.063 234.152 230.952 234.14C230.445 234.093 213.784 231.25 213.731 231.203C213.702 231.174 213.871 230.346 214.116 229.367L214.564 227.584L215.607 227.707C216.178 227.771 219.639 228.19 223.291 228.633C226.944 229.076 230.51 229.501 231.22 229.583C232.024 229.67 232.479 229.81 232.432 229.95C232.391 230.078 232.088 231.075 231.756 232.17Z" fill="#EFE7A8" />
											<path d="M124.959 219.635C124.528 219.408 124.126 219.268 124.074 219.321C123.94 219.454 125.052 220.047 125.437 220.047C125.606 220.047 125.39 219.861 124.959 219.635Z" fill="#EFE7A8" />
											<path d="M128.196 219.864C128.126 219.753 127.957 219.66 127.829 219.66C127.683 219.66 127.707 219.741 127.893 219.864C128.284 220.114 128.353 220.114 128.202 219.864H128.196Z" fill="#EFE7A8" />
											<path d="M106.491 216.448C106.24 216.401 105.827 216.401 105.57 216.448C105.314 216.494 105.524 216.535 106.031 216.535C106.538 216.535 106.742 216.494 106.491 216.448Z" fill="#EFE7A8" />
											<path d="M103.111 215.656C103.042 215.586 102.867 215.581 102.721 215.639C102.558 215.703 102.605 215.755 102.844 215.761C103.059 215.767 103.181 215.72 103.111 215.656Z" fill="#EFE7A8" />
											<path d="M127.533 214C127.283 213.954 126.869 213.954 126.613 214C126.362 214.047 126.566 214.088 127.073 214.088C127.58 214.088 127.784 214.047 127.533 214Z" fill="#EFE7A8" />
											<path d="M96.5724 213.406C96.5025 213.336 96.3278 213.33 96.1822 213.388C96.019 213.452 96.0656 213.505 96.3045 213.511C96.52 213.522 96.6423 213.47 96.5724 213.406Z" fill="#EFE7A8" />
											<path d="M96.1662 211.36C96.0963 211.29 95.9215 211.284 95.7759 211.342C95.6128 211.407 95.6594 211.459 95.8982 211.465C96.1138 211.476 96.2361 211.424 96.1662 211.36Z" fill="#EFE7A8" />
											<path d="M108.074 210.87C107.794 210.649 107.381 210.475 107.153 210.475C106.851 210.475 106.926 210.579 107.462 210.87C108.388 211.376 108.726 211.376 108.074 210.87Z" fill="#EFE7A8" />
											<path d="M104.598 210.667C104.429 210.557 104.155 210.475 103.986 210.481C103.782 210.487 103.817 210.551 104.091 210.667C104.65 210.906 104.977 210.906 104.604 210.667H104.598Z" fill="#EFE7A8" />
											<path d="M204.369 149.695C204.189 149.165 204.008 148.763 203.962 148.809C203.921 148.856 204.032 149.322 204.212 149.852C204.393 150.383 204.573 150.785 204.62 150.738C204.661 150.697 204.55 150.225 204.369 149.695Z" fill="#EFE7A8" />
											<path d="M203.661 147.748C203.533 147.387 203.393 147.13 203.352 147.171C203.311 147.212 203.375 147.544 203.503 147.905C203.632 148.266 203.765 148.523 203.812 148.482C203.859 148.441 203.789 148.109 203.661 147.748Z" fill="#EFE7A8" />
											<path d="M202.429 144.28C202.191 143.581 201.963 143.044 201.922 143.085C201.882 143.126 202.039 143.738 202.272 144.437C202.511 145.136 202.738 145.673 202.779 145.632C202.82 145.591 202.662 144.979 202.429 144.28Z" fill="#EFE7A8" />
											<path d="M40.6311 143.78C40.8 143.576 40.7884 143.506 40.5904 143.506C40.4447 143.506 40.3223 143.628 40.3223 143.78C40.3223 143.931 40.3398 144.053 40.3631 144.053C40.3864 144.053 40.5087 143.931 40.6311 143.78Z" fill="#EFE7A8" />
											<path d="M41.2968 142.876C41.5531 142.549 41.5472 142.544 41.221 142.8C40.8831 143.068 40.7724 143.237 40.9413 143.237C40.9821 143.237 41.1453 143.074 41.2968 142.881V142.876Z" fill="#EFE7A8" />
											<path d="M201.514 141.722C201.333 141.192 201.153 140.79 201.106 140.836C201.065 140.877 201.176 141.349 201.356 141.879C201.537 142.41 201.718 142.812 201.764 142.765C201.805 142.718 201.694 142.252 201.514 141.722Z" fill="#EFE7A8" />
											<path d="M200.593 139.169C200.465 138.808 200.331 138.551 200.284 138.592C200.237 138.633 200.307 138.965 200.436 139.326C200.564 139.687 200.698 139.943 200.744 139.903C200.785 139.856 200.721 139.53 200.593 139.169Z" fill="#EFE7A8" />
											<path d="M199.575 136.308C199.447 135.947 199.307 135.691 199.266 135.731C199.225 135.778 199.29 136.104 199.418 136.465C199.546 136.826 199.686 137.083 199.726 137.042C199.773 137.001 199.703 136.669 199.575 136.308Z" fill="#EFE7A8" />
											<path d="M156.775 20.4416C156.705 20.0804 156.6 19.83 156.548 19.8824C156.495 19.9348 156.519 20.2669 156.594 20.6163C156.781 21.4551 156.944 21.2861 156.775 20.4357V20.4416Z" fill="#EFE7A8" />
											<path d="M139.497 16.8404C139.433 16.7764 139.223 16.9799 139.025 17.294L138.664 17.8638L139.136 17.4103C139.398 17.1603 139.556 16.9043 139.497 16.8404Z" fill="#EFE7A8" />
											<path d="M140.782 14.6612C140.945 14.3588 140.945 14.2774 140.782 14.3763C140.66 14.4519 140.456 14.702 140.333 14.9346C140.17 15.237 140.17 15.3184 140.333 15.2195C140.456 15.1439 140.66 14.8938 140.782 14.6612Z" fill="#EFE7A8" />
										</svg>
									</div>

									<div className="services-brand-identity w-[100%] h-[100%] services-visuals-items object-contain flex items-center justify-center">
										<svg viewBox="0 0 234 234" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M93.1225 4.30957C92.5811 4.36779 92.0454 4.43766 91.5039 4.50753C92.0396 4.43766 92.5811 4.37362 93.1225 4.30957Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M59.2891 15.2142L62.2464 13.6207C62.2464 13.6207 62.2406 13.6207 62.2348 13.6207C62.3163 13.5742 62.4037 13.5335 62.4852 13.487C62.7937 13.3299 63.1081 13.1787 63.4166 13.0217C63.2128 13.1264 63.0032 13.2136 62.7995 13.3183C63.271 13.0682 63.731 12.8298 64.2083 12.5855L66.2809 11.6434C66.0946 11.7248 65.9199 11.8237 65.7336 11.9051C68.266 10.7362 70.8625 9.66607 73.523 8.73557C84.8811 6.06036 96.6059 4.94375 116.79 4.60645C79.4029 6.45001 66.5603 11.7772 62.2523 13.6091C61.2568 14.1267 60.2613 14.6501 59.2891 15.2026V15.2142Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M89.0547 3.40225C90.5101 3.0475 91.983 2.70437 93.2404 2.41941L94.0263 2.26238C98.3402 1.58777 106.886 2.93118 116.795 4.61773C115.939 4.50141 115.089 4.39673 114.239 4.3095C97.8162 2.44267 93.0775 2.74508 89.0547 3.40225Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M101.162 1.06464C102.46 0.895989 104.061 0.709888 105.319 0.570312C105.336 0.570312 105.354 0.570312 105.377 0.570312C105.615 0.628469 105.65 0.6401 116.793 4.61802C103.84 1.18677 102.565 1.15188 100.836 1.11117C100.941 1.09372 101.057 1.08209 101.168 1.07046L101.162 1.06464Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M156.46 226.916C156.18 227.015 155.889 227.12 155.592 227.224C153.514 227.922 150.946 228.725 148.955 229.335C146.912 229.923 144.147 230.574 142.074 231.063C169.058 224.479 192.077 209.708 210.496 187.166L205.315 193.552C204.669 194.279 204.092 194.924 203.557 195.512C201.636 197.506 199.365 199.821 197.06 202.031C195.622 203.339 193.846 204.91 191.39 207.085C190.12 208.102 188.636 209.231 187.116 210.359C174.029 220.001 165.087 223.549 156.465 226.916H156.46Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M110.928 0.319861C111.097 0.261705 111.324 0.180286 111.498 0.116314C111.51 0.116314 111.522 0.116314 111.533 0.116314C112.744 0.0581571 113.49 0.0407095 113.565 0.0407095C114.246 0.0290782 115.114 0.00581567 115.842 0C114.468 0.052341 114.433 0.0930513 113.816 0.901429C114.076 1.83969 115.069 3.08036 116.797 4.62345C111.3 1.57023 111.132 0.994479 110.928 0.325677V0.319861Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M225.897 159.682C204.45 210.272 150.739 229.633 131.772 232.831C131.679 232.843 131.592 232.854 131.499 232.866C130.492 232.988 129.24 233.116 128.274 233.227L126.277 233.401C126.242 233.401 126.207 233.401 126.172 233.407C137.373 232.372 214.347 209.685 231.666 139.874C231.48 140.909 231.288 141.915 231.102 142.857C229.815 147.725 227.842 154.093 226.177 158.943C226.083 159.199 225.99 159.432 225.897 159.676V159.682Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M120.067 0.900794C117.407 1.90109 117.273 2.47684 116.79 4.61701C114.845 0.266886 118.88 0.185467 122.437 0.109863C123.683 0.173836 125.342 0.290148 126.588 0.377383L127.769 0.482066C125.947 0.359937 122.157 0.109862 120.067 0.894977V0.900794Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M119.426 233.744C118.977 233.755 118.535 233.761 118.087 233.767H117.9C117.83 233.767 117.755 233.767 117.679 233.767C117.173 233.767 116.678 233.767 116.177 233.767C115.746 233.767 115.321 233.761 114.943 233.755C114.92 233.755 114.896 233.755 114.873 233.755C123.745 233.598 250.861 185.474 230.323 87.7065C230.323 87.7124 230.323 87.724 230.328 87.7298C231.033 90.4864 231.72 94.1968 232.308 96.9709C232.878 100.524 233.344 105.311 233.734 108.887C235.83 196.593 131.057 232.61 119.426 233.738V233.744Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M138.597 2.03522C138.836 2.08174 139.08 2.13409 139.325 2.18061C125.021 -0.267785 119.054 3.26232 116.789 4.61737C120.841 0.162574 127.885 0.24981 138.597 2.03522Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M218.91 59.4484C270.548 158.896 125.909 229.109 108.612 233.471C108.496 233.465 108.374 233.453 108.251 233.442L107.495 233.383C107.378 233.372 107.25 233.36 107.128 233.354C106.243 233.279 105.189 233.168 104.299 233.075C104.188 233.064 104.072 233.052 103.955 233.034C124.442 217.478 149.37 208.998 169.123 192.267C178.787 184.078 201.427 164.904 214.66 139.257C241.131 87.9452 217.571 55.2204 206.009 41.1465C206.416 41.6176 206.812 42.077 207.202 42.5364L209.153 44.8627C212.209 49.0674 216.063 54.8249 218.817 59.2623C218.851 59.3204 218.881 59.3786 218.916 59.4368L218.91 59.4484Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M143.882 3.15233C143.813 3.13488 143.743 3.11743 143.673 3.09999C143.853 3.1407 144.057 3.18141 144.226 3.22211C145.512 3.50708 147.207 3.97234 148.476 4.32128C151.096 5.04823 154.565 6.1125 157.103 7.0779C158.658 7.66529 160.736 8.44459 162.267 9.09594C164.107 9.87524 166.517 11.0035 168.322 11.8468C170.173 12.7133 172.589 13.9811 174.353 15.0163C176.426 16.2318 178.981 17.802 181.263 19.2675C204.643 35.3304 223.104 61.1113 220.548 90.1838C214.523 158.745 136.792 205.776 107.526 223.485C100.773 227.571 97.1985 230.413 96.8026 232.01C96.7386 231.999 96.6746 231.987 96.6105 231.976C95.0096 231.679 92.9836 231.254 91.3942 230.917C91.336 230.906 91.2837 230.894 91.2255 230.882C90.6549 230.684 90.2416 229.87 89.8516 229.405C91.1789 226.852 93.7928 225.008 107.864 215.796C144.069 192.103 180.501 164.857 201.762 126.247C249.75 39.0815 156.673 -6.00735 116.8 4.61788C124.537 1.63444 133.939 1.30295 143.888 3.15233H143.882Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M103.412 206.049C81.3829 221.6 76.1318 225.305 83.1003 228.736C83.0246 228.713 82.9489 228.69 82.8791 228.672C81.8137 228.341 80.5854 227.934 79.3919 227.538C78.5769 227.259 77.7735 226.974 76.9643 226.683C67.1024 222.1 75.701 215.773 96.234 200.676C118.956 183.967 147.232 163.176 171.235 132.749C242.067 42.9489 166.467 -1.48865 116.802 4.6178C173.237 -7.5951 294.66 71.056 103.418 206.049H103.412Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M90.4503 188.566C64.765 208.246 55.1302 215.621 67.8855 222.96C67.7865 222.914 67.6876 222.867 67.5886 222.821C65.4521 221.803 62.7916 220.401 60.7423 219.354C50.7931 213.545 54.7692 206.804 60.5443 200.389C84.7101 173.55 116.805 155.76 141.553 129.59C221.211 45.338 167.774 3.44775 116.787 4.6167C168.746 -0.12307 261.538 57.5102 90.4503 188.566Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M70.6053 172.295C46.1251 191.888 37.4101 202.415 50.4681 213.005C48.2326 211.435 45.4033 209.219 43.1736 207.515C42.05 206.59 40.8857 205.59 39.7621 204.613C29.6032 195.32 35.3026 190.307 103.632 130.19C202.676 43.0538 158.035 12.2832 125.766 5.84521C155.043 11.2945 236.668 39.3842 70.6111 172.295H70.6053Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M118.098 4.72217C120.508 4.9376 123.093 5.31023 125.76 5.84006C122.319 5.1996 119.606 4.87355 118.098 4.72217Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M116.795 4.6167C116.876 4.6167 117.336 4.64581 118.099 4.7215C117.657 4.68075 117.22 4.64581 116.795 4.6167Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M75.1643 133.922C34.564 166.56 19.3229 181.494 32.5323 197.714C32.4391 197.621 32.3635 197.534 32.2761 197.441C30.1978 195.214 27.7003 192.259 25.75 190.003C25.7092 189.95 25.6685 189.904 25.6278 189.852C14.0717 174.713 25.1155 158.79 72.7833 121.791C197.14 25.2681 131.262 7.24538 116.789 4.6167C127.332 5.94849 215.752 20.8947 75.1586 133.928L75.1643 133.922Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M66.761 107.817C20.8222 142.094 8.1717 159.628 16.7703 177.163C16.421 176.587 16.0834 176.011 15.7515 175.447L15.4313 174.895C15.1984 174.493 14.983 174.115 14.7676 173.731L12.142 168.683C11.8218 168.032 11.5133 167.392 11.2106 166.764C0.946982 143.269 39.8125 115.005 65.6141 96.2552C149.65 35.179 139.829 12.7131 116.792 4.62354C136.464 9.75295 170.969 30.0671 66.7668 107.823L66.761 107.817Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M64.5228 81.1974C24.4115 109.421 0.379595 128.31 5.38041 151.869C5.1359 151.067 4.89722 150.27 4.66436 149.485C3.86097 146.548 3.06922 143.245 2.41137 140.61C-1.02923 117.132 23.2296 99.2376 63.0906 71.9912C89.422 53.9917 138.44 20.4877 116.79 4.6167C150.759 20.5109 85.8476 66.1872 64.517 81.1974H64.5228Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M61.5875 60.4355C16.3822 89.729 1.02461 103.024 0.215399 123.192C0.192112 122.791 0.163007 122.396 0.145542 122L0 117.068L0.110649 112.288C0.133935 111.741 0.157225 111.206 0.186333 110.66C1.92119 89.4905 30.1679 72.0435 65.878 49.9963C90.9927 34.486 119.466 16.911 116.794 4.6167C128.554 17.0448 88.2565 43.1571 61.5875 60.4355Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M64.5048 41.7391C22.8682 65.3565 7.20206 76.8192 2.21289 94.1208C2.84163 91.1258 3.85462 87.3398 4.71041 84.1295C4.90253 83.4665 5.09464 82.8094 5.29258 82.1464C12.0632 64.5598 34.7444 51.934 74.1164 31.2418C101.961 16.6038 111.136 10.8812 116.795 4.62354C113.552 13.9228 92.9786 25.5948 64.5048 41.7449V41.7391Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M11.2422 66.8977C11.411 66.5488 11.5798 66.194 11.7486 65.8392L14.118 61.1635L15.7073 58.3719C16.0042 57.866 16.3012 57.3542 16.6097 56.8424C21.9773 48.5144 31.6878 42.3149 45.5725 35.0511C68.5157 23.0476 93.1414 14.9812 116.789 4.62354C109.413 9.31096 95.8601 15.5337 78.6978 23.4081C33.1724 44.298 19.1305 53.3356 11.2363 66.9035L11.2422 66.8977Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M25.4336 44.1526C25.649 43.8851 25.8527 43.635 26.0739 43.3617C26.2195 43.193 26.3534 43.0244 26.4989 42.8499C26.6736 42.6405 26.854 42.4254 27.0345 42.216C28.7577 40.2154 30.6963 38.0578 32.2449 36.3131C42.4212 25.8972 70.8658 15.2371 116.787 4.62354C47.1367 25.4727 33.6596 35.2547 25.4277 44.1584L25.4336 44.1526Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M44.5355 25.1751C46.2355 23.8724 48.0984 22.5057 49.6935 21.3193C50.0254 21.0925 50.3514 20.8657 50.6891 20.6447C61.7386 13.6775 83.9599 8.28639 116.794 4.6167C96.3775 7.64666 59.8407 14.4801 43.0859 26.3557C43.5808 25.9486 44.0582 25.5589 44.5355 25.1751Z" fill="#F9AAD4" fillOpacity="0.5" />
											<path d="M90.8752 4.59464C88.1506 4.96684 85.461 5.44954 82.8238 6.05437C78.1373 6.82785 77.5609 7.01395 74.0039 8.17127C74.1029 8.13056 74.2193 8.08404 74.3183 8.04333C76.1056 7.34545 78.5274 6.51381 80.3437 5.86827C80.3554 5.86827 80.3729 5.85664 80.3903 5.85082C84.6751 4.47251 89.7049 4.28059 95.5383 4.05959C95.2705 4.08286 95.0085 4.11775 94.7407 4.14101C97.7214 3.86186 100.749 3.71065 103.817 3.71647C108.538 3.9491 109.161 3.99562 116.793 4.61208C104.667 4.11193 99.1826 4.19336 90.8809 4.58882L90.8752 4.59464ZM93.1223 4.30967C92.5809 4.36783 92.0453 4.43761 91.5039 4.5074C92.0395 4.43761 92.5809 4.37364 93.1223 4.30967Z" fill="#F9AAD4" fillOpacity="0.5" />
										</svg>
									</div>

									<div className="services-social-media w-[100%] h-[100%] services-visuals-items object-contain flex items-center justify-center">
										<svg viewBox="0 0 268 269" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M135.263 268.126L134.873 234.612L134.648 201.093L134.461 134.066L134.648 67.0328L134.873 33.519L135.263 0L135.653 33.519L135.877 67.0328L136.059 134.066L135.872 201.093L135.647 234.612L135.263 268.126Z" fill="#CFDFCF" />
											<path d="M141.552 264.953L139.574 233.052L137.762 201.146L134.395 137.318L131.391 73.4683L130.023 41.5354L128.82 9.59717L130.798 41.4978L132.61 73.404L135.977 137.238L138.976 201.087L140.344 233.015L141.552 264.953Z" fill="#CFDFCF" />
											<path d="M147.844 261.788L144.279 231.5L140.874 201.201L134.327 140.572L128.142 79.9058L125.176 49.5591L122.381 19.1963L125.946 49.4787L129.35 79.7825L135.893 140.406L142.077 201.073L145.043 231.419L147.844 261.788Z" fill="#CFDFCF" />
											<path d="M154.133 258.614L148.981 229.95L143.994 201.259L134.261 143.835L124.892 86.3461L120.332 57.5856L115.934 28.793L121.091 57.457L126.078 86.1478L135.806 143.572L145.175 201.061L149.734 229.822L154.133 258.614Z" fill="#CFDFCF" />
											<path d="M160.425 255.441L153.691 228.396L147.111 201.318L134.203 147.093L121.643 92.7923L115.491 65.6073L109.494 38.3901L116.234 65.4358L122.813 92.5137L135.721 146.739L148.276 201.045L154.428 228.224L160.425 255.441Z" fill="#CFDFCF" />
											<path d="M166.717 252.275L158.401 226.848L150.239 201.378L134.151 150.362L118.405 99.2395L110.655 73.6354L103.055 47.9883L111.377 73.4103L119.538 98.8805L135.626 149.901L151.372 201.024L159.122 226.623L166.717 252.275Z" fill="#CFDFCF" />
											<path d="M173.011 249.103L163.112 225.305L153.363 201.442L134.095 153.631L115.163 105.686L105.815 81.6629L96.6113 57.5859L106.51 81.3842L116.259 105.241L135.522 153.058L154.459 201.003L163.807 225.026L173.011 249.103Z" fill="#CFDFCF" />
											<path d="M179.304 245.93L167.829 223.755L156.498 201.505L134.055 156.899L111.933 112.132L100.981 89.6948L90.1738 67.1826L101.649 89.3572L112.986 111.607L135.423 156.213L157.545 200.98L168.497 223.423L179.304 245.93Z" fill="#CFDFCF" />
											<path d="M185.596 242.763L172.55 222.207L159.637 201.57L134.019 160.168L108.7 118.579L96.1504 97.7228L83.7344 76.7808L96.7864 97.3316L109.7 117.968L135.312 159.37L160.625 200.959L173.18 221.821L185.596 242.763Z" fill="#CFDFCF" />
											<path d="M191.886 239.591L177.268 220.659L162.773 201.635L133.986 163.438L105.476 125.032L91.3232 105.751L77.293 86.3789L91.9112 105.306L106.406 124.33L135.194 162.532L163.703 200.939L177.856 220.219L191.886 239.591Z" fill="#CFDFCF" />
											<path d="M198.176 236.418L181.992 219.109L165.92 201.693L133.958 166.7L102.258 131.472L86.4959 113.777L70.8516 95.9751L87.0411 113.279L103.113 130.695L135.07 165.687L166.77 200.921L182.532 218.616L198.176 236.418Z" fill="#CFDFCF" />
											<path d="M204.467 233.244L186.716 217.554L169.068 201.751L133.936 169.963L99.0394 137.912L81.674 121.798L64.4102 105.566L82.1605 121.257L99.8091 137.065L134.941 168.853L169.837 200.904L187.208 217.018L204.467 233.244Z" fill="#CFDFCF" />
											<path d="M210.762 230.079L191.446 216.001L172.22 201.806L133.919 173.217L95.8262 144.355L76.852 129.822L57.9688 115.166L77.285 129.238L96.5104 143.438L134.806 172.027L172.904 200.895L191.878 215.423L210.762 230.079Z" fill="#CFDFCF" />
											<path d="M217.054 226.906L196.177 214.447L175.375 201.854L133.904 176.464L92.6097 150.785L72.0321 137.838L51.5293 124.763L72.4063 137.222L93.2084 149.815L134.674 175.21L175.968 200.889L196.551 213.831L217.054 226.906Z" fill="#CFDFCF" />
											<path d="M223.346 223.734L200.903 212.883L178.529 201.897L133.889 179.707L89.3986 157.211L67.2121 145.855L45.0898 134.361L67.5328 145.212L89.9064 156.203L134.541 178.394L179.032 200.89L201.223 212.245L223.346 223.734Z" fill="#CFDFCF" />
											<path d="M229.636 220.567L205.632 211.318L181.682 201.935L133.872 182.938L86.1855 163.631L62.3902 153.867L38.6484 143.958L62.6522 153.202L86.6024 162.591L134.412 181.588L182.093 200.895L205.894 210.659L229.636 220.567Z" fill="#CFDFCF" />
											<path d="M235.928 217.395L210.358 209.753L184.831 201.967L133.852 186.164L82.9743 170.045L57.565 161.872L32.209 153.556L57.7788 161.197L83.3058 168.984L134.285 184.787L185.163 200.906L210.567 209.078L235.928 217.395Z" fill="#CFDFCF" />
											<path d="M242.216 214.222L215.08 208.183L187.976 201.994L133.828 189.39L79.7486 176.459L52.741 169.879L25.7656 163.153L52.9013 169.193L80.0051 175.382L134.154 187.991L188.228 200.922L215.24 207.502L242.216 214.222Z" fill="#CFDFCF" />
											<path d="M248.513 211.055L219.806 206.608L191.125 202.015L133.802 192.605L76.5321 182.868L47.9157 177.885L19.3262 172.751L48.028 177.193L76.7084 181.786L134.032 191.196L191.302 200.938L219.918 205.922L248.513 211.055Z" fill="#CFDFCF" />
											<path d="M254.805 207.883L224.526 205.032L194.269 202.042L133.771 195.82L73.3044 189.272L43.0846 185.885L12.8809 182.348L43.1594 185.194L73.4219 188.189L133.915 194.411L194.381 200.959L224.601 204.346L254.805 207.883Z" fill="#CFDFCF" />
											<path d="M261.095 204.71L229.245 203.456L197.406 202.057L133.732 199.03L70.0752 195.675L38.2573 193.885L6.43945 191.945L38.2894 193.194L70.1341 194.593L133.802 197.626L197.459 200.98L229.277 202.775L261.095 204.71Z" fill="#CFDFCF" />
											<path d="M267.387 201.543L233.965 201.881L200.539 202.079L133.696 202.24L66.848 202.079L33.4267 201.886L0 201.543L33.4267 201.2L66.848 201.002L133.696 200.841L200.539 201.007L233.965 201.2L267.387 201.543Z" fill="#CFDFCF" />
										</svg>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	)
}

export default ServicesSection